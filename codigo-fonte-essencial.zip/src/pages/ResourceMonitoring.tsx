import { ResourceMonitoringDashboard } from "@/components/dashboard/ResourceMonitoringDashboard";

const ResourceMonitoring = () => {
  return <ResourceMonitoringDashboard />;
};

export default ResourceMonitoring;
