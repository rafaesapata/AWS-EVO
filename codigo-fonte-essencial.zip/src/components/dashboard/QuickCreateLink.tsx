import { useState, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Zap, 
  Copy, 
  CheckCircle2, 
  ExternalLink,
  Info
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

// ============================================================================
// CONSTANTS - Import from parent or use shared constants
// ============================================================================

// EVO Platform AWS Account ID - used to restrict IAM Role trust policy
const EVO_PLATFORM_ACCOUNT_ID = '992382761234';

// Template path - hosted locally in public folder
const LOCAL_TEMPLATE_PATH = '/cloudformation/evo-platform-role.yaml';

// AWS Regions for Quick Create
const AWS_REGIONS = [
  { value: 'us-east-1', label: 'US East (N. Virginia)' },
  { value: 'us-east-2', label: 'US East (Ohio)' },
  { value: 'us-west-1', label: 'US West (N. California)' },
  { value: 'us-west-2', label: 'US West (Oregon)' },
  { value: 'eu-west-1', label: 'Europe (Ireland)' },
  { value: 'eu-west-2', label: 'Europe (London)' },
  { value: 'eu-central-1', label: 'Europe (Frankfurt)' },
  { value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' },
  { value: 'ap-southeast-2', label: 'Asia Pacific (Sydney)' },
  { value: 'ap-northeast-1', label: 'Asia Pacific (Tokyo)' },
  { value: 'sa-east-1', label: 'South America (São Paulo)' },
];

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Generates CloudFormation Quick Create URL
 */
const generateQuickCreateUrl = (
  region: string,
  templateUrl: string,
  externalId: string,
  accountName: string,
  evoPlatformAccountId: string
): string => {
  const params = new URLSearchParams();
  params.append('templateURL', templateUrl);
  params.append('stackName', `EVO-Platform-${Date.now().toString(36)}`);
  params.append('param_ExternalId', externalId);
  params.append('param_AccountName', accountName || 'AWS Account');
  params.append('param_EVOPlatformAccountId', evoPlatformAccountId);
  
  return `https://${region}.console.aws.amazon.com/cloudformation/home?region=${region}#/stacks/quickcreate?${params.toString()}`;
};

// ============================================================================
// COMPONENT
// ============================================================================

interface QuickCreateLinkProps {
  /** External ID from parent - REQUIRED to maintain consistency */
  externalId: string;
  /** Initial region selection */
  initialRegion?: string;
  /** Callback when user opens the Quick Create link */
  onLinkOpened?: () => void;
}

export const QuickCreateLink = ({ 
  externalId, 
  initialRegion = 'us-east-1',
  onLinkOpened 
}: QuickCreateLinkProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [region, setRegion] = useState(initialRegion);
  const [accountName, setAccountName] = useState('');
  const [copied, setCopied] = useState(false);
  
  // Generate the Quick Create URL - uses local template as fallback
  const quickCreateUrl = useMemo(() => {
    // Check if S3 template is available, otherwise use local
    const templateUrl = `${window.location.origin}${LOCAL_TEMPLATE_PATH}`;
    
    return generateQuickCreateUrl(
      region,
      templateUrl,
      externalId,
      accountName,
      EVO_PLATFORM_ACCOUNT_ID
    );
  }, [region, externalId, accountName]);
  
  /**
   * Copy Quick Create URL to clipboard
   */
  const copyUrl = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(quickCreateUrl);
      setCopied(true);
      toast({
        title: "Link copiado!",
        description: "Cole no navegador para abrir o CloudFormation",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Erro ao copiar",
        description: "Clique no botão 'Abrir' para acessar diretamente",
        variant: "destructive",
      });
    }
  }, [quickCreateUrl, toast]);
  
  /**
   * Open Quick Create URL in new tab
   */
  const openQuickCreate = useCallback(() => {
    window.open(quickCreateUrl, '_blank', 'noopener,noreferrer');
    onLinkOpened?.();
    toast({
      title: "Abrindo CloudFormation...",
      description: "Revise os parâmetros e clique em 'Create stack'",
    });
  }, [quickCreateUrl, toast, onLinkOpened]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <Zap className="w-4 h-4" />
          Quick Create Link
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            CloudFormation Quick Create
          </DialogTitle>
          <DialogDescription>
            Gere um link direto para criar a stack do CloudFormation com um clique.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* Region Selection */}
          <div className="space-y-2">
            <Label htmlFor="qc-region">Região AWS</Label>
            <Select value={region} onValueChange={setRegion}>
              <SelectTrigger id="qc-region">
                <SelectValue placeholder="Selecione a região" />
              </SelectTrigger>
              <SelectContent>
                {AWS_REGIONS.map((r) => (
                  <SelectItem key={r.value} value={r.value}>
                    {r.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Account Name */}
          <div className="space-y-2">
            <Label htmlFor="qc-account-name">Nome da Conta (opcional)</Label>
            <Input
              id="qc-account-name"
              placeholder="Production / Development"
              value={accountName}
              onChange={(e) => setAccountName(e.target.value)}
              maxLength={64}
            />
          </div>
          
          {/* External ID Display */}
          <div className="space-y-2">
            <Label>External ID (gerado automaticamente)</Label>
            <div className="flex items-center gap-2 p-2 bg-muted rounded-md font-mono text-sm">
              <code className="flex-1 truncate">{externalId}</code>
            </div>
          </div>
          
          {/* Info Alert */}
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              O link Quick Create pré-preenche todos os parâmetros do CloudFormation.
              Basta clicar em "Create stack" na console AWS.
            </AlertDescription>
          </Alert>
          
          {/* Generated URL (truncated) */}
          <div className="space-y-2">
            <Label>URL Gerada</Label>
            <div className="p-2 bg-muted rounded-md text-xs font-mono break-all max-h-20 overflow-y-auto">
              {quickCreateUrl}
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <Button
              variant="outline"
              className="flex-1 gap-2"
              onClick={copyUrl}
            >
              {copied ? (
                <CheckCircle2 className="w-4 h-4 text-green-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
              {copied ? "Copiado!" : "Copiar Link"}
            </Button>
            <Button
              className="flex-1 gap-2"
              onClick={openQuickCreate}
            >
              <ExternalLink className="w-4 h-4" />
              Abrir CloudFormation
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuickCreateLink;
