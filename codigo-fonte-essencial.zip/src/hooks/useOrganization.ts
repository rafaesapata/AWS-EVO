import { useQuery } from '@tanstack/react-query';
import { cognitoAuth } from '@/integrations/aws/cognito-client-simple';
import { apiClient } from '@/integrations/aws/api-client';
import { CACHE_CONFIGS } from './useQueryCache';
import { useTVDashboard } from '@/contexts/TVDashboardContext';

/**
 * Hook para obter a organização do usuário atual
 * Inclui suporte a impersonation para super admins e modo TV Dashboard
 * Cache isolado por sessão de usuário com retry automático
 */
export const useOrganization = () => {
  const { organizationId: tvOrgId, isTVMode } = useTVDashboard();
  
  // In TV mode, return organization ID directly from context without query
  if (isTVMode && tvOrgId) {
    return {
      data: tvOrgId,
      isLoading: false,
      isError: false,
      isSuccess: true,
      error: null,
      refetch: () => Promise.resolve({ data: tvOrgId }),
    } as any;
  }
  
  // If in TV mode but no orgId yet, show loading
  if (isTVMode && !tvOrgId) {
    return {
      data: null,
      isLoading: true,
      isError: false,
      isSuccess: false,
      error: null,
      refetch: () => Promise.resolve({ data: null }),
    } as any;
  }
  
  return useQuery({
    queryKey: ['user-organization'],
    queryFn: async () => {
      const user = await cognitoAuth.getCurrentUser();
      if (!user) throw new Error('Not authenticated');

      // Return organization ID from user attributes or use RPC call
      if (user.organizationId) {
        return user.organizationId;
      }

      // Use the server-side function that checks impersonation
      const result = await apiClient.rpc('get_user_organization', { _user_id: user.id });

      if (result.error) {
        console.error('Failed to get user organization:', result.error);
        throw new Error(result.error.message);
      }
      if (!result.data) {
        console.error('User has no organization');
        throw new Error('User has no organization');
      }

      return result.data as string;
    },
    ...CACHE_CONFIGS.SETTINGS, // 5 minutos de cache
    // Reduce retry count and delays for faster feedback
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(500 * 2 ** attemptIndex, 2000),
    // Keep previous data while refetching to prevent UI flickering
    placeholderData: (previousData) => previousData,
  });
};
