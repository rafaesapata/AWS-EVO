import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecsPatterns from 'aws-cdk-lib/aws-ecs-patterns';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as iam from 'aws-cdk-lib/aws-iam';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import * as rds from 'aws-cdk-lib/aws-rds';
import * as elasticloadbalancingv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import { Construct } from 'constructs';

export interface EcsStackProps extends cdk.StackProps {
  vpc: ec2.IVpc;
  database: rds.IDatabaseInstance;
  environment: string;
}

export class EcsStack extends cdk.Stack {
  public readonly cluster: ecs.ICluster;
  public readonly apiService: ecs.FargateService;
  public readonly workerService: ecs.FargateService;
  public readonly loadBalancer: elasticloadbalancingv2.IApplicationLoadBalancer;

  constructor(scope: Construct, id: string, props: EcsStackProps) {
    super(scope, id, props);

    // Create ECS Cluster
    this.cluster = new ecs.Cluster(this, 'EvoUdsCluster', {
      vpc: props.vpc,
      clusterName: `evo-uds-${props.environment}-cluster`,
      containerInsights: true,
      enableFargateCapacityProviders: true,
    });

    // Create ECR Repositories
    const apiRepository = new ecr.Repository(this, 'ApiRepository', {
      repositoryName: `evo-uds-${props.environment}-api`,
      imageScanOnPush: true,
      lifecycleRules: [
        {
          maxImageCount: 10,
          tagStatus: ecr.TagStatus.UNTAGGED,
        },
        {
          maxImageAge: cdk.Duration.days(30),
          tagStatus: ecr.TagStatus.ANY,
        },
      ],
    });

    const workerRepository = new ecr.Repository(this, 'WorkerRepository', {
      repositoryName: `evo-uds-${props.environment}-worker`,
      imageScanOnPush: true,
      lifecycleRules: [
        {
          maxImageCount: 10,
          tagStatus: ecr.TagStatus.UNTAGGED,
        },
        {
          maxImageAge: cdk.Duration.days(30),
          tagStatus: ecr.TagStatus.ANY,
        },
      ],
    });

    // Create CloudWatch Log Groups
    const apiLogGroup = new logs.LogGroup(this, 'ApiLogGroup', {
      logGroupName: `/ecs/evo-uds-${props.environment}-api`,
      retention: logs.RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    const workerLogGroup = new logs.LogGroup(this, 'WorkerLogGroup', {
      logGroupName: `/ecs/evo-uds-${props.environment}-worker`,
      retention: logs.RetentionDays.ONE_MONTH,
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    // Create Secrets
    const appSecrets = new secretsmanager.Secret(this, 'AppSecrets', {
      secretName: `evo-uds-${props.environment}-secrets`,
      description: 'EVO UDS Application Secrets',
      generateSecretString: {
        secretStringTemplate: JSON.stringify({
          NODE_ENV: props.environment,
          LOG_LEVEL: 'info',
        }),
        generateStringKey: 'JWT_SECRET',
        excludeCharacters: '"@/\\',
      },
    });

    // Create Task Execution Role
    const taskExecutionRole = new iam.Role(this, 'TaskExecutionRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
      managedPolicies: [
        iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AmazonECSTaskExecutionRolePolicy'),
      ],
    });

    // Add permissions for secrets and ECR
    taskExecutionRole.addToPolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: [
          'secretsmanager:GetSecretValue',
          'kms:Decrypt',
        ],
        resources: [appSecrets.secretArn],
      })
    );

    // Create Task Role for application permissions
    const taskRole = new iam.Role(this, 'TaskRole', {
      assumedBy: new iam.ServicePrincipal('ecs-tasks.amazonaws.com'),
    });

    // Add application permissions
    taskRole.addToPolicy(
      new iam.PolicyStatement({
        effect: iam.Effect.ALLOW,
        actions: [
          'bedrock:InvokeModel',
          'bedrock:InvokeModelWithResponseStream',
          's3:GetObject',
          's3:PutObject',
          's3:DeleteObject',
          'cloudwatch:PutMetricData',
          'logs:CreateLogStream',
          'logs:PutLogEvents',
        ],
        resources: ['*'],
      })
    );

    // API Task Definition
    const apiTaskDefinition = new ecs.FargateTaskDefinition(this, 'ApiTaskDefinition', {
      family: `evo-uds-${props.environment}-api`,
      cpu: 1024, // 1 vCPU
      memoryLimitMiB: 2048, // 2 GB
      executionRole: taskExecutionRole,
      taskRole: taskRole,
    });

    // API Container
    const apiContainer = apiTaskDefinition.addContainer('ApiContainer', {
      containerName: 'evo-uds-api',
      image: ecs.ContainerImage.fromEcrRepository(apiRepository, 'latest'),
      logging: ecs.LogDrivers.awsLogs({
        streamPrefix: 'evo-uds-api',
        logGroup: apiLogGroup,
      }),
      environment: {
        NODE_ENV: props.environment,
        PORT: '3000',
        DATABASE_HOST: props.database.instanceEndpoint.hostname,
        DATABASE_PORT: props.database.instanceEndpoint.port.toString(),
      },
      secrets: {
        DATABASE_URL: ecs.Secret.fromSecretsManager(appSecrets, 'DATABASE_URL'),
        JWT_SECRET: ecs.Secret.fromSecretsManager(appSecrets, 'JWT_SECRET'),
        BEDROCK_REGION: ecs.Secret.fromSecretsManager(appSecrets, 'BEDROCK_REGION'),
      },
      healthCheck: {
        command: ['CMD-SHELL', 'curl -f http://localhost:3000/health || exit 1'],
        interval: cdk.Duration.seconds(30),
        timeout: cdk.Duration.seconds(5),
        retries: 3,
        startPeriod: cdk.Duration.seconds(60),
      },
    });

    apiContainer.addPortMappings({
      containerPort: 3000,
      protocol: ecs.Protocol.TCP,
    });

    // Worker Task Definition
    const workerTaskDefinition = new ecs.FargateTaskDefinition(this, 'WorkerTaskDefinition', {
      family: `evo-uds-${props.environment}-worker`,
      cpu: 2048, // 2 vCPU
      memoryLimitMiB: 4096, // 4 GB
      executionRole: taskExecutionRole,
      taskRole: taskRole,
    });

    // Worker Container
    const workerContainer = workerTaskDefinition.addContainer('WorkerContainer', {
      containerName: 'evo-uds-worker',
      image: ecs.ContainerImage.fromEcrRepository(workerRepository, 'latest'),
      logging: ecs.LogDrivers.awsLogs({
        streamPrefix: 'evo-uds-worker',
        logGroup: workerLogGroup,
      }),
      environment: {
        NODE_ENV: props.environment,
        WORKER_TYPE: 'background',
        DATABASE_HOST: props.database.instanceEndpoint.hostname,
        DATABASE_PORT: props.database.instanceEndpoint.port.toString(),
      },
      secrets: {
        DATABASE_URL: ecs.Secret.fromSecretsManager(appSecrets, 'DATABASE_URL'),
        JWT_SECRET: ecs.Secret.fromSecretsManager(appSecrets, 'JWT_SECRET'),
        BEDROCK_REGION: ecs.Secret.fromSecretsManager(appSecrets, 'BEDROCK_REGION'),
      },
    });

    // Create Application Load Balancer
    const alb = new elasticloadbalancingv2.ApplicationLoadBalancer(this, 'LoadBalancer', {
      vpc: props.vpc,
      internetFacing: true,
      loadBalancerName: `evo-uds-${props.environment}-alb`,
    });

    this.loadBalancer = alb;

    // Create API Service
    this.apiService = new ecs.FargateService(this, 'ApiService', {
      cluster: this.cluster,
      taskDefinition: apiTaskDefinition,
      serviceName: `evo-uds-${props.environment}-api`,
      desiredCount: props.environment === 'production' ? 3 : 1,
      assignPublicIp: false,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
      },
      enableExecuteCommand: true,
      capacityProviderStrategies: [
        {
          capacityProvider: 'FARGATE',
          weight: 1,
        },
        {
          capacityProvider: 'FARGATE_SPOT',
          weight: props.environment === 'production' ? 0 : 1,
        },
      ],
    });

    // Create Worker Service
    this.workerService = new ecs.FargateService(this, 'WorkerService', {
      cluster: this.cluster,
      taskDefinition: workerTaskDefinition,
      serviceName: `evo-uds-${props.environment}-worker`,
      desiredCount: props.environment === 'production' ? 2 : 1,
      assignPublicIp: false,
      vpcSubnets: {
        subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
      },
      enableExecuteCommand: true,
      capacityProviderStrategies: [
        {
          capacityProvider: 'FARGATE',
          weight: 1,
        },
        {
          capacityProvider: 'FARGATE_SPOT',
          weight: props.environment === 'production' ? 0 : 2,
        },
      ],
    });

    // Create Target Group for API
    const apiTargetGroup = new elasticloadbalancingv2.ApplicationTargetGroup(this, 'ApiTargetGroup', {
      vpc: props.vpc,
      port: 3000,
      protocol: elasticloadbalancingv2.ApplicationProtocol.HTTP,
      targetType: elasticloadbalancingv2.TargetType.IP,
      healthCheck: {
        enabled: true,
        path: '/health',
        protocol: elasticloadbalancingv2.Protocol.HTTP,
        healthyHttpCodes: '200',
        interval: cdk.Duration.seconds(30),
        timeout: cdk.Duration.seconds(5),
        healthyThresholdCount: 2,
        unhealthyThresholdCount: 3,
      },
    });

    // Attach API Service to Target Group
    this.apiService.attachToApplicationTargetGroup(apiTargetGroup);

    // Create ALB Listener
    const listener = alb.addListener('Listener', {
      port: 80,
      protocol: elasticloadbalancingv2.ApplicationProtocol.HTTP,
      defaultTargetGroups: [apiTargetGroup],
    });

    // Auto Scaling for API Service
    const apiScaling = this.apiService.autoScaleTaskCount({
      minCapacity: props.environment === 'production' ? 2 : 1,
      maxCapacity: props.environment === 'production' ? 10 : 3,
    });

    apiScaling.scaleOnCpuUtilization('ApiCpuScaling', {
      targetUtilizationPercent: 70,
      scaleInCooldown: cdk.Duration.minutes(5),
      scaleOutCooldown: cdk.Duration.minutes(2),
    });

    apiScaling.scaleOnMemoryUtilization('ApiMemoryScaling', {
      targetUtilizationPercent: 80,
      scaleInCooldown: cdk.Duration.minutes(5),
      scaleOutCooldown: cdk.Duration.minutes(2),
    });

    // Auto Scaling for Worker Service
    const workerScaling = this.workerService.autoScaleTaskCount({
      minCapacity: props.environment === 'production' ? 1 : 1,
      maxCapacity: props.environment === 'production' ? 5 : 2,
    });

    workerScaling.scaleOnCpuUtilization('WorkerCpuScaling', {
      targetUtilizationPercent: 75,
      scaleInCooldown: cdk.Duration.minutes(10),
      scaleOutCooldown: cdk.Duration.minutes(3),
    });

    // Security Groups
    const albSecurityGroup = new ec2.SecurityGroup(this, 'AlbSecurityGroup', {
      vpc: props.vpc,
      description: 'Security group for ALB',
      allowAllOutbound: true,
    });

    albSecurityGroup.addIngressRule(
      ec2.Peer.anyIpv4(),
      ec2.Port.tcp(80),
      'Allow HTTP traffic from anywhere'
    );

    albSecurityGroup.addIngressRule(
      ec2.Peer.anyIpv4(),
      ec2.Port.tcp(443),
      'Allow HTTPS traffic from anywhere'
    );

    alb.addSecurityGroup(albSecurityGroup);

    const ecsSecurityGroup = new ec2.SecurityGroup(this, 'EcsSecurityGroup', {
      vpc: props.vpc,
      description: 'Security group for ECS tasks',
      allowAllOutbound: true,
    });

    ecsSecurityGroup.addIngressRule(
      albSecurityGroup,
      ec2.Port.tcp(3000),
      'Allow traffic from ALB'
    );

    this.apiService.connections.addSecurityGroup(ecsSecurityGroup);
    this.workerService.connections.addSecurityGroup(ecsSecurityGroup);

    // Outputs
    new cdk.CfnOutput(this, 'ClusterName', {
      value: this.cluster.clusterName,
      description: 'ECS Cluster Name',
    });

    new cdk.CfnOutput(this, 'LoadBalancerDns', {
      value: alb.loadBalancerDnsName,
      description: 'Load Balancer DNS Name',
    });

    new cdk.CfnOutput(this, 'ApiRepositoryUri', {
      value: apiRepository.repositoryUri,
      description: 'API ECR Repository URI',
    });

    new cdk.CfnOutput(this, 'WorkerRepositoryUri', {
      value: workerRepository.repositoryUri,
      description: 'Worker ECR Repository URI',
    });

    new cdk.CfnOutput(this, 'ApiServiceName', {
      value: this.apiService.serviceName,
      description: 'API Service Name',
    });

    new cdk.CfnOutput(this, 'WorkerServiceName', {
      value: this.workerService.serviceName,
      description: 'Worker Service Name',
    });

    // Tags
    cdk.Tags.of(this).add('Project', 'EVO-UDS');
    cdk.Tags.of(this).add('Environment', props.environment);
    cdk.Tags.of(this).add('Component', 'ECS');
  }
}