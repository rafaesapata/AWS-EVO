/**
 * Input validation utilities using Zod
 * Provides type-safe validation for Lambda handlers
 */

import { z } from 'zod';
import { badRequest } from './response.js';
import type { APIGatewayProxyResultV2 } from '../types/lambda.js';

// Common validation schemas
export const commonSchemas = {
  // AWS Account ID validation
  awsAccountId: z.string().regex(/^\d{12}$/, 'Invalid AWS Account ID format'),
  
  // Organization ID validation
  organizationId: z.string().uuid('Invalid organization ID format'),
  
  // AWS Region validation
  awsRegion: z.string().regex(/^[a-z0-9-]+$/, 'Invalid AWS region format'),
  
  // Pagination
  pagination: z.object({
    page: z.number().int().min(1).default(1),
    limit: z.number().int().min(1).max(100).default(20),
  }),
  
  // Date range
  dateRange: z.object({
    startDate: z.string().datetime().optional(),
    endDate: z.string().datetime().optional(),
  }),
  
  // Severity levels
  severity: z.enum(['critical', 'high', 'medium', 'low']),
  
  // Scan levels
  scanLevel: z.enum(['basic', 'advanced', 'military']).default('military'),
};

// Security scan request validation
export const securityScanSchema = z.object({
  accountId: z.string().optional(),
  scanLevel: commonSchemas.scanLevel,
  regions: z.array(commonSchemas.awsRegion).optional(),
  scanTypes: z.array(z.string()).optional(),
});

// Findings query validation
export const findingsQuerySchema = z.object({
  accountId: z.string().optional(),
  severity: z.array(commonSchemas.severity).optional(),
  status: z.array(z.enum(['pending', 'acknowledged', 'resolved', 'false_positive'])).optional(),
  service: z.array(z.string()).optional(),
  category: z.array(z.string()).optional(),
  ...commonSchemas.pagination.shape,
  ...commonSchemas.dateRange.shape,
});

// Cost analysis request validation
export const costAnalysisSchema = z.object({
  accountId: z.string().optional(),
  service: z.string().optional(),
  granularity: z.enum(['DAILY', 'MONTHLY', 'HOURLY']).default('DAILY'),
  ...commonSchemas.dateRange.shape,
});

// Compliance scan validation
export const complianceScanSchema = z.object({
  accountId: z.string().optional(),
  frameworks: z.array(z.enum(['CIS', 'PCI-DSS', 'SOC2', 'LGPD', 'GDPR'])).optional(),
  ...commonSchemas.dateRange.shape,
});

/**
 * Validation middleware for Lambda handlers
 */
export function validateInput<T>(
  schema: z.ZodSchema<T>,
  input: unknown
): { success: true; data: T } | { success: false; error: APIGatewayProxyResultV2 } {
  try {
    const result = schema.parse(input);
    return { success: true, data: result };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errorMessages = error.errors.map(err => 
        `${err.path.join('.')}: ${err.message}`
      ).join(', ');
      
      return {
        success: false,
        error: badRequest(`Validation error: ${errorMessages}`, {
          validationErrors: error.errors,
        }),
      };
    }
    
    return {
      success: false,
      error: badRequest('Invalid input format'),
    };
  }
}

/**
 * Parse and validate JSON body from Lambda event
 */
export function parseAndValidateBody<T>(
  schema: z.ZodSchema<T>,
  body: string | null
): { success: true; data: T } | { success: false; error: APIGatewayProxyResultV2 } {
  if (!body) {
    return validateInput(schema, {});
  }
  
  try {
    const parsed = JSON.parse(body);
    return validateInput(schema, parsed);
  } catch (error) {
    return {
      success: false,
      error: badRequest('Invalid JSON format'),
    };
  }
}

/**
 * Validate query parameters
 */
export function validateQueryParams<T>(
  schema: z.ZodSchema<T>,
  queryParams: Record<string, string> | null
): { success: true; data: T } | { success: false; error: APIGatewayProxyResultV2 } {
  // Convert query string parameters to appropriate types
  const processedParams: Record<string, unknown> = {};
  
  if (queryParams) {
    for (const [key, value] of Object.entries(queryParams)) {
      // Try to parse numbers
      if (/^\d+$/.test(value)) {
        processedParams[key] = parseInt(value, 10);
      }
      // Try to parse booleans
      else if (value === 'true' || value === 'false') {
        processedParams[key] = value === 'true';
      }
      // Try to parse arrays (comma-separated)
      else if (value.includes(',')) {
        processedParams[key] = value.split(',').map(v => v.trim());
      }
      // Keep as string
      else {
        processedParams[key] = value;
      }
    }
  }
  
  return validateInput(schema, processedParams);
}

/**
 * Sanitize string input to prevent injection attacks
 */
export function sanitizeString(input: string): string {
  return input
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/['"]/g, '') // Remove quotes
    .replace(/[;\\]/g, '') // Remove potential SQL injection chars
    .trim();
}

/**
 * Validate and sanitize organization context
 */
export function validateOrganizationContext(
  organizationId: string,
  userOrgId: string
): { success: true } | { success: false; error: APIGatewayProxyResultV2 } {
  if (organizationId !== userOrgId) {
    return {
      success: false,
      error: badRequest('Access denied: Organization mismatch'),
    };
  }
  
  const validation = validateInput(commonSchemas.organizationId, organizationId);
  if (!validation.success) {
    return validation;
  }
  
  return { success: true };
}

/**
 * Rate limiting validation (basic implementation)
 */
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();

export function checkRateLimit(
  identifier: string,
  maxRequests: number = 100,
  windowMs: number = 60000 // 1 minute
): { success: true } | { success: false; error: APIGatewayProxyResultV2 } {
  const now = Date.now();
  const key = identifier;
  
  const current = rateLimitMap.get(key);
  
  if (!current || now > current.resetTime) {
    // Reset or initialize
    rateLimitMap.set(key, { count: 1, resetTime: now + windowMs });
    return { success: true };
  }
  
  if (current.count >= maxRequests) {
    return {
      success: false,
      error: {
        statusCode: 429,
        headers: {
          'Content-Type': 'application/json',
          'Retry-After': Math.ceil((current.resetTime - now) / 1000).toString(),
        },
        body: JSON.stringify({
          error: 'Rate limit exceeded',
          message: `Too many requests. Try again in ${Math.ceil((current.resetTime - now) / 1000)} seconds.`,
        }),
      },
    };
  }
  
  // Increment counter
  current.count++;
  return { success: true };
}