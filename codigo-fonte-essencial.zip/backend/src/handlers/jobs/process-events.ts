/**
 * Lambda handler for Process Events
 * AWS Lambda Handler for process-events
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getPrismaClient } from '../../lib/database.js';

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🚀 Process Events started');
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const prisma = getPrismaClient();
    
    // Buscar eventos pendentes
    const pendingEvents = await prisma.systemEvent.findMany({
      where: {
        processed: false,
      },
      orderBy: { createdAt: 'asc' },
      take: 50,
    });
    
    console.log(`Found ${pendingEvents.length} pending events`);
    
    const results = [];
    
    for (const evt of pendingEvents) {
      try {
        // Processar evento baseado no tipo
        await processEvent(prisma, evt);
        
        // Marcar como processado
        await prisma.systemEvent.update({
          where: { id: evt.id },
          data: {
            processed: true,
            processedAt: new Date(),
          },
        });
        
        results.push({
          eventId: evt.id,
          eventType: evt.eventType,
          status: 'processed',
        });
        
      } catch (err) {
        console.error(`Error processing event ${evt.id}:`, err);
        
        results.push({
          eventId: evt.id,
          eventType: evt.eventType,
          status: 'failed',
          error: err instanceof Error ? err.message : 'Unknown error',
        });
      }
    }
    
    console.log(`✅ Processed ${results.length} events`);
    
    return success({
      success: true,
      eventsProcessed: results.length,
      results,
    });
    
  } catch (err) {
    console.error('❌ Process Events error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}

async function processEvent(prisma: any, event: any) {
  const { eventType, payload } = event;
  
  switch (eventType) {
    case 'user_created':
      await handleUserCreated(prisma, payload);
      break;
    
    case 'alert_triggered':
      await handleAlertTriggered(prisma, payload);
      break;
    
    case 'scan_completed':
      await handleScanCompleted(prisma, payload);
      break;
    
    case 'cost_threshold_exceeded':
      await handleCostThreshold(prisma, payload);
      break;
    
    default:
      console.log(`Unknown event type: ${eventType}`);
  }
}

async function handleUserCreated(prisma: any, payload: any) {
  console.log('Processing user_created event');
}

async function handleAlertTriggered(prisma: any, payload: any) {
  console.log('Processing alert_triggered event');
}

async function handleScanCompleted(prisma: any, payload: any) {
  console.log('Processing scan_completed event');
}

async function handleCostThreshold(prisma: any, payload: any) {
  console.log('Processing cost_threshold_exceeded event');
}
