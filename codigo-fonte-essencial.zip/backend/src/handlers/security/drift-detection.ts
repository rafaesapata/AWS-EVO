/**
 * Lambda handler for Drift Detection
 * AWS Lambda Handler for drift-detection
 * 
 * Detecta mudanças não autorizadas em recursos AWS (drift)
 * comparando estado atual vs estado esperado no inventário
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getUserFromEvent, getOrganizationId } from '../../lib/auth.js';
import { getPrismaClient } from '../../lib/database.js';
import { resolveAwsCredentials, toAwsCredentials } from '../../lib/aws-helpers.js';
import { EC2Client, DescribeInstancesCommand } from '@aws-sdk/client-ec2';

interface DriftDetectionRequest {
  accountId?: string;
  regions?: string[];
}

interface DriftItem {
  aws_account_id: string;
  resource_id: string;
  resource_type: string;
  resource_name: string | null;
  drift_type: 'created' | 'configuration_drift' | 'deleted';
  detected_at: Date;
  severity: 'critical' | 'high' | 'medium' | 'low';
  diff: any;
  expected_state: any;
  actual_state: any;
}

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🚀 Drift Detection started');
  const startTime = Date.now();
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const user = getUserFromEvent(event);
    const organizationId = getOrganizationId(user);
    
    const body: DriftDetectionRequest = event.body ? JSON.parse(event.body) : {};
    const { accountId, regions: requestedRegions } = body;
    
    const prisma = getPrismaClient();
    
    // Buscar credenciais AWS ativas
    const awsAccounts = await prisma.awsCredentials.findMany({
      where: {
        organizationId,
        isActive: true,
        ...(accountId && { id: accountId }),
      },
    });
    
    if (awsAccounts.length === 0) {
      return success({
        success: true,
        message: 'No AWS credentials configured. Please configure AWS credentials first.',
        drifts: [],
        stats: {
          total: 0,
          created: 0,
          modified: 0,
          deleted: 0,
          critical: 0,
          high: 0,
        },
      });
    }
    
    const detectedDrifts: DriftItem[] = [];
    
    // Processar cada conta AWS
    for (const account of awsAccounts) {
      const regions = requestedRegions || account.regions || ['us-east-1'];
      
      // Resolver credenciais via AssumeRole
      let resolvedCreds;
      try {
        resolvedCreds = await resolveAwsCredentials(account, regions[0]);
        console.log(`✅ Credentials resolved for account ${account.id}`);
      } catch (err) {
        console.error(`❌ Failed to resolve credentials for account ${account.id}:`, err);
        continue;
      }
      
      // Escanear cada região
      for (const region of regions) {
        console.log(`Scanning for drift in region ${region}...`);
        
        const regionDrifts = await detectDriftsInRegion(
          prisma,
          account.id,
          region,
          resolvedCreds
        );
        
        detectedDrifts.push(...regionDrifts);
      }
    }
    
    // Salvar drifts detectados
    if (detectedDrifts.length > 0) {
      await prisma.driftDetection.createMany({
        data: detectedDrifts,
        skipDuplicates: true,
      });
    }
    
    // Calcular estatísticas
    const executionTime = ((Date.now() - startTime) / 1000).toFixed(2);
    const createdCount = detectedDrifts.filter(d => d.drift_type === 'created').length;
    const modifiedCount = detectedDrifts.filter(d => d.drift_type === 'configuration_drift').length;
    const deletedCount = detectedDrifts.filter(d => d.drift_type === 'deleted').length;
    const criticalCount = detectedDrifts.filter(d => d.severity === 'critical').length;
    const highCount = detectedDrifts.filter(d => d.severity === 'high').length;
    
    // Salvar histórico
    await prisma.driftDetectionHistory.create({
      data: {
        organizationId,
        totalDrifts: detectedDrifts.length,
        createdCount,
        modifiedCount,
        deletedCount,
        criticalCount,
        highCount,
        executionTimeSeconds: parseFloat(executionTime),
        message: `Detected ${detectedDrifts.length} drifts (${createdCount} created, ${modifiedCount} modified, ${deletedCount} deleted)`,
      },
    });
    
    console.log(`✅ Detected ${detectedDrifts.length} drifts in ${executionTime}s`);
    
    return success({
      success: true,
      drifts_detected: detectedDrifts.length,
      execution_time: executionTime,
      summary: {
        created: createdCount,
        configuration_drift: modifiedCount,
        deleted: deletedCount,
        critical: criticalCount,
        high: highCount,
      },
      drifts: detectedDrifts,
    });
    
  } catch (err) {
    console.error('❌ Drift Detection error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}

async function detectDriftsInRegion(
  prisma: any,
  accountId: string,
  region: string,
  credentials: any
): Promise<DriftItem[]> {
  const drifts: DriftItem[] = [];
  
  try {
    // Obter instâncias EC2 atuais
    const ec2Client = new EC2Client({
      region,
      credentials: toAwsCredentials(credentials),
    });
    
    const response = await ec2Client.send(new DescribeInstancesCommand({}));
    const currentInstances: any[] = [];
    
    if (response.Reservations) {
      for (const reservation of response.Reservations) {
        if (reservation.Instances) {
          currentInstances.push(...reservation.Instances);
        }
      }
    }
    
    // Obter estado esperado do inventário
    const expectedResources = await prisma.resourceInventory.findMany({
      where: {
        awsAccountId: accountId,
        resourceType: 'EC2::Instance',
        region,
      },
    });
    
    // Comparar estado atual vs esperado
    for (const current of currentInstances) {
      const expected = expectedResources.find(
        (r: any) => r.resourceId === current.InstanceId
      );
      
      if (!expected) {
        // Recurso criado fora do IaC
        drifts.push({
          aws_account_id: accountId,
          resource_id: current.InstanceId!,
          resource_type: 'EC2::Instance',
          resource_name: current.Tags?.find((t: any) => t.Key === 'Name')?.Value || null,
          drift_type: 'created',
          detected_at: new Date(),
          severity: 'high',
          diff: {
            instanceType: current.InstanceType,
            state: current.State?.Name,
            securityGroups: current.SecurityGroups?.map((sg: any) => sg.GroupId),
          },
          expected_state: null,
          actual_state: {
            instanceType: current.InstanceType,
            state: current.State?.Name,
          },
        });
      } else {
        // Comparar configurações
        const expectedMeta = (expected.metadata as any) || {};
        if (expectedMeta.instanceType && expectedMeta.instanceType !== current.InstanceType) {
          drifts.push({
            aws_account_id: accountId,
            resource_id: current.InstanceId!,
            resource_type: 'EC2::Instance',
            resource_name: current.Tags?.find((t: any) => t.Key === 'Name')?.Value || expected.resourceName,
            drift_type: 'configuration_drift',
            detected_at: new Date(),
            severity: 'medium',
            diff: {
              field: 'instanceType',
              expected: expectedMeta.instanceType,
              actual: current.InstanceType,
            },
            expected_state: expectedMeta,
            actual_state: {
              instanceType: current.InstanceType,
              state: current.State?.Name,
            },
          });
        }
      }
    }
    
    // Verificar recursos deletados (existem no inventário mas não na AWS)
    for (const expected of expectedResources) {
      const exists = currentInstances.some((c: any) => c.InstanceId === expected.resourceId);
      if (!exists) {
        drifts.push({
          aws_account_id: accountId,
          resource_id: expected.resourceId,
          resource_type: 'EC2::Instance',
          resource_name: expected.resourceName,
          drift_type: 'deleted',
          detected_at: new Date(),
          severity: 'critical',
          diff: { message: 'Resource no longer exists in AWS' },
          expected_state: expected.metadata,
          actual_state: null,
        });
      }
    }
    
  } catch (err) {
    console.error(`Error detecting drifts in region ${region}:`, err);
  }
  
  return drifts;
}
