/**
 * Lambda handler for KB Analytics Dashboard
 * AWS Lambda Handler for kb-analytics-dashboard
 * 
 * Retorna analytics da knowledge base
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getUserFromEvent, getOrganizationId } from '../../lib/auth.js';
import { getPrismaClient } from '../../lib/database.js';

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🚀 KB Analytics Dashboard started');
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const user = getUserFromEvent(event);
    const organizationId = getOrganizationId(user);
    
    const prisma = getPrismaClient();
    
    // Total de artigos
    const totalArticles = await prisma.knowledgeBaseArticle.count({
      where: { organizationId },
    });
    
    // Artigos publicados
    const publishedArticles = await prisma.knowledgeBaseArticle.count({
      where: {
        organizationId,
        status: 'published',
      },
    });
    
    // Top 10 artigos mais visualizados
    const topArticles = await prisma.knowledgeBaseArticle.findMany({
      where: { organizationId },
      orderBy: { viewCount: 'desc' },
      take: 10,
      select: {
        id: true,
        title: true,
        viewCount: true,
        createdAt: true,
      },
    });
    
    // Artigos por categoria
    const articlesByCategory = await prisma.knowledgeBaseArticle.groupBy({
      by: ['category'],
      where: { organizationId },
      _count: true,
    });
    
    // Total de visualizações
    const totalViews = await prisma.knowledgeBaseArticle.aggregate({
      where: { organizationId },
      _sum: {
        viewCount: true,
      },
    });
    
    // Artigos criados nos últimos 30 dias
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const recentArticles = await prisma.knowledgeBaseArticle.count({
      where: {
        organizationId,
        createdAt: {
          gte: thirtyDaysAgo,
        },
      },
    });
    
    // Tags mais usadas
    const allArticles = await prisma.knowledgeBaseArticle.findMany({
      where: { organizationId },
      select: { tags: true },
    });
    
    const tagCounts: Record<string, number> = {};
    allArticles.forEach(article => {
      article.tags?.forEach(tag => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
    });
    
    const topTags = Object.entries(tagCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([tag, count]) => ({ tag, count }));
    
    console.log(`✅ KB Analytics: ${totalArticles} articles, ${totalViews._sum.viewCount} views`);
    
    return success({
      success: true,
      summary: {
        totalArticles,
        publishedArticles,
        draftArticles: totalArticles - publishedArticles,
        totalViews: totalViews._sum.viewCount || 0,
        recentArticles,
      },
      topArticles,
      articlesByCategory: articlesByCategory.map(c => ({
        category: c.category,
        count: c._count,
      })),
      topTags,
    });
    
  } catch (err) {
    console.error('❌ KB Analytics Dashboard error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}
