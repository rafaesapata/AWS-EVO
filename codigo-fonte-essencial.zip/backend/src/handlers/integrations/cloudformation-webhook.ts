import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { PrismaClient } from '@prisma/client';
import { SNSClient, PublishCommand } from '@aws-sdk/client-sns';

const prisma = new PrismaClient();
const snsClient = new SNSClient({});

interface CloudFormationEvent {
  StackId: string;
  StackName: string;
  LogicalResourceId: string;
  PhysicalResourceId?: string;
  ResourceType: string;
  ResourceStatus: string;
  ResourceStatusReason?: string;
  Timestamp: string;
  RequestId: string;
}

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    const body = JSON.parse(event.body || '{}');
    const cfEvent: CloudFormationEvent = body;

    // Validar evento
    if (!cfEvent.StackId || !cfEvent.ResourceStatus) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Invalid CloudFormation event' }) };
    }

    // Extrair account ID do StackId
    const accountId = cfEvent.StackId.split(':')[4];

    // Buscar conta AWS
    const awsAccount = await prisma.awsAccount.findFirst({
      where: { accountId },
      include: { organization: true }
    });

    if (!awsAccount) {
      console.log(`AWS Account ${accountId} not found, skipping event`);
      return { statusCode: 200, body: JSON.stringify({ message: 'Account not monitored' }) };
    }

    // Registrar evento de drift/mudança
    const eventType = getEventType(cfEvent.ResourceStatus);
    
    await prisma.cloudFormationEvent.create({
      data: {
        awsAccountId: awsAccount.id,
        stackId: cfEvent.StackId,
        stackName: cfEvent.StackName,
        resourceId: cfEvent.LogicalResourceId,
        physicalResourceId: cfEvent.PhysicalResourceId,
        resourceType: cfEvent.ResourceType,
        status: cfEvent.ResourceStatus,
        statusReason: cfEvent.ResourceStatusReason,
        eventType,
        timestamp: new Date(cfEvent.Timestamp),
        rawEvent: cfEvent as unknown as Record<string, unknown>
      }
    });

    // Verificar se é um evento crítico que requer notificação
    const criticalStatuses = [
      'CREATE_FAILED', 'UPDATE_FAILED', 'DELETE_FAILED',
      'ROLLBACK_IN_PROGRESS', 'ROLLBACK_COMPLETE',
      'UPDATE_ROLLBACK_IN_PROGRESS', 'UPDATE_ROLLBACK_COMPLETE'
    ];

    if (criticalStatuses.includes(cfEvent.ResourceStatus)) {
      // Buscar configurações de alerta
      const alertConfig = await prisma.alertConfiguration.findFirst({
        where: { 
          organizationId: awsAccount.organizationId,
          eventType: 'CLOUDFORMATION_FAILURE',
          enabled: true
        }
      });

      if (alertConfig) {
        // Enviar notificação SNS
        const message = {
          type: 'CLOUDFORMATION_EVENT',
          severity: 'HIGH',
          account: awsAccount.accountId,
          accountName: awsAccount.name,
          stack: cfEvent.StackName,
          resource: cfEvent.LogicalResourceId,
          status: cfEvent.ResourceStatus,
          reason: cfEvent.ResourceStatusReason,
          timestamp: cfEvent.Timestamp
        };

        if (process.env.ALERT_SNS_TOPIC_ARN) {
          await snsClient.send(new PublishCommand({
            TopicArn: process.env.ALERT_SNS_TOPIC_ARN,
            Subject: `CloudFormation Alert: ${cfEvent.StackName} - ${cfEvent.ResourceStatus}`,
            Message: JSON.stringify(message, null, 2)
          }));
        }

        // Registrar alerta
        await prisma.alert.create({
          data: {
            organizationId: awsAccount.organizationId,
            awsAccountId: awsAccount.id,
            type: 'CLOUDFORMATION_FAILURE',
            severity: 'HIGH',
            title: `CloudFormation ${cfEvent.ResourceStatus}: ${cfEvent.StackName}`,
            description: cfEvent.ResourceStatusReason || `Resource ${cfEvent.LogicalResourceId} failed`,
            resourceId: cfEvent.LogicalResourceId,
            resourceType: cfEvent.ResourceType,
            status: 'OPEN',
            metadata: message as unknown as Record<string, unknown>
          }
        });
      }
    }

    // Verificar drift detection
    if (cfEvent.ResourceStatus === 'UPDATE_COMPLETE' || cfEvent.ResourceStatus === 'CREATE_COMPLETE') {
      await checkForDrift(awsAccount.id, cfEvent);
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        eventId: cfEvent.RequestId,
        processed: true
      })
    };
  } catch (error) {
    console.error('CloudFormation webhook error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error' })
    };
  }
};

function getEventType(status: string): string {
  if (status.includes('CREATE')) return 'CREATE';
  if (status.includes('UPDATE')) return 'UPDATE';
  if (status.includes('DELETE')) return 'DELETE';
  if (status.includes('ROLLBACK')) return 'ROLLBACK';
  return 'OTHER';
}

async function checkForDrift(awsAccountId: string, event: CloudFormationEvent): Promise<void> {
  // Buscar baseline do recurso
  const baseline = await prisma.resourceBaseline.findFirst({
    where: {
      awsAccountId,
      resourceId: event.LogicalResourceId,
      resourceType: event.ResourceType
    }
  });

  if (baseline) {
    // Marcar como potencial drift para análise posterior
    await prisma.driftDetection.create({
      data: {
        awsAccountId,
        resourceId: event.LogicalResourceId,
        resourceType: event.ResourceType,
        stackName: event.StackName,
        detectedAt: new Date(),
        status: 'PENDING_ANALYSIS',
        changeType: 'CLOUDFORMATION_UPDATE'
      }
    });
  }
}
