/**
 * Lambda handler para sincronizar contas da organização
 * AWS Lambda Handler for sync-organization-accounts
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getUserFromEvent, getOrganizationId } from '../../lib/auth.js';
import { getPrismaClient } from '../../lib/database.js';
import { OrganizationsClient, ListAccountsCommand } from '@aws-sdk/client-organizations';

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🔄 Sync organization accounts started');
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const user = getUserFromEvent(event);
    const organizationId = getOrganizationId(user);
    
    const prisma = getPrismaClient();
    
    // Listar contas da AWS Organizations
    const orgsClient = new OrganizationsClient({ region: 'us-east-1' });
    
    let allAccounts: any[] = [];
    let nextToken: string | undefined;
    
    do {
      const response = await orgsClient.send(
        new ListAccountsCommand({
          NextToken: nextToken,
          MaxResults: 20,
        })
      );
      
      if (response.Accounts) {
        allAccounts.push(...response.Accounts);
      }
      
      nextToken = response.NextToken;
    } while (nextToken);
    
    console.log(`📊 Found ${allAccounts.length} accounts in AWS Organizations`);
    
    // Sincronizar com banco de dados
    let created = 0;
    let updated = 0;
    
    for (const awsAccount of allAccounts) {
      if (!awsAccount.Id) continue;
      
      const existingAccount = await prisma.awsAccount.findFirst({
        where: {
          organization_id: organizationId,
          account_id: awsAccount.Id,
        },
      });
      
      if (existingAccount) {
        // Atualizar
        await prisma.awsAccount.update({
          where: { id: existingAccount.id },
          data: {
            account_name: awsAccount.Name || existingAccount.account_name,
            email: awsAccount.Email || existingAccount.email,
            status: awsAccount.Status || existingAccount.status,
          },
        });
        updated++;
      } else {
        // Criar
        await prisma.awsAccount.create({
          data: {
            organization_id: organizationId,
            account_id: awsAccount.Id,
            account_name: awsAccount.Name || 'Unknown',
            email: awsAccount.Email,
            status: awsAccount.Status || 'ACTIVE',
          },
        });
        created++;
      }
    }
    
    console.log(`✅ Sync completed: ${created} created, ${updated} updated`);
    
    return success({
      total_accounts: allAccounts.length,
      created,
      updated,
      synced_at: new Date().toISOString(),
    });
    
  } catch (err) {
    console.error('❌ Sync accounts error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}
