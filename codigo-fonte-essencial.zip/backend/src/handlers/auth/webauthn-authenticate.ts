import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { PrismaClient } from '@prisma/client';
import * as crypto from 'crypto';

const prisma = new PrismaClient();

interface AuthenticationRequest {
  action: 'start' | 'finish';
  email?: string;
  assertion?: {
    id: string;
    rawId: string;
    type: string;
    response: {
      clientDataJSON: string;
      authenticatorData: string;
      signature: string;
      userHandle?: string;
    };
  };
  challenge?: string;
}

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    const body: AuthenticationRequest = JSON.parse(event.body || '{}');
    const { action } = body;

    if (action === 'start') {
      return await startAuthentication(body.email);
    } else if (action === 'finish') {
      return await finishAuthentication(body, event);
    }

    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid action' }) };
  } catch (error) {
    console.error('WebAuthn authentication error:', error);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal server error' }) };
  }
};

async function startAuthentication(email?: string): Promise<APIGatewayProxyResult> {
  let allowCredentials: { type: string; id: string }[] = [];

  if (email) {
    // Buscar credenciais do usuário específico
    const user = await prisma.user.findUnique({
      where: { email },
      include: { webauthnCredentials: true }
    });

    if (!user || user.webauthnCredentials.length === 0) {
      return { statusCode: 404, body: JSON.stringify({ error: 'No WebAuthn credentials found' }) };
    }

    allowCredentials = user.webauthnCredentials.map(cred => ({
      type: 'public-key',
      id: cred.credentialId
    }));
  }

  // Gerar challenge
  const challenge = crypto.randomBytes(32).toString('base64url');
  const challengeExpiry = new Date(Date.now() + 300000); // 5 minutos

  // Salvar challenge
  await prisma.webauthnChallenge.create({
    data: {
      challenge,
      type: 'AUTHENTICATION',
      email,
      expiresAt: challengeExpiry
    }
  });

  const rpId = process.env.WEBAUTHN_RP_ID || 'evouds.com';

  const publicKeyCredentialRequestOptions = {
    challenge,
    rpId,
    timeout: 300000,
    userVerification: 'preferred',
    allowCredentials: allowCredentials.length > 0 ? allowCredentials : undefined
  };

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      success: true,
      options: publicKeyCredentialRequestOptions
    })
  };
}

async function finishAuthentication(
  body: AuthenticationRequest,
  event: APIGatewayProxyEvent
): Promise<APIGatewayProxyResult> {
  const { assertion, challenge } = body;

  if (!assertion || !challenge) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing assertion or challenge' }) };
  }

  // Verificar challenge
  const storedChallenge = await prisma.webauthnChallenge.findFirst({
    where: {
      challenge,
      type: 'AUTHENTICATION',
      expiresAt: { gt: new Date() }
    }
  });

  if (!storedChallenge) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid or expired challenge' }) };
  }

  // Deletar challenge usado
  await prisma.webauthnChallenge.delete({ where: { id: storedChallenge.id } });

  // Buscar credencial
  const credential = await prisma.webauthnCredential.findFirst({
    where: { credentialId: assertion.id },
    include: { user: { include: { organization: true } } }
  });

  if (!credential) {
    // Registrar tentativa falha
    await prisma.securityEvent.create({
      data: {
        eventType: 'WEBAUTHN_AUTH_FAILED',
        severity: 'MEDIUM',
        details: { credentialId: assertion.id, reason: 'Credential not found' },
        ipAddress: event.requestContext.identity?.sourceIp,
        createdAt: new Date()
      }
    });

    return { statusCode: 401, body: JSON.stringify({ error: 'Invalid credential' }) };
  }

  try {
    // Decodificar clientDataJSON
    const clientDataJSON = Buffer.from(assertion.response.clientDataJSON, 'base64');
    const clientData = JSON.parse(clientDataJSON.toString());

    // Verificar challenge
    if (clientData.challenge !== challenge) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Challenge mismatch' }) };
    }

    // Verificar tipo
    if (clientData.type !== 'webauthn.get') {
      return { statusCode: 400, body: JSON.stringify({ error: 'Invalid type' }) };
    }

    // Decodificar authenticatorData
    const authenticatorData = Buffer.from(assertion.response.authenticatorData, 'base64');
    
    // Extrair counter (bytes 33-36)
    const counter = authenticatorData.readUInt32BE(33);

    // Verificar counter (proteção contra replay)
    if (counter <= credential.counter) {
      await prisma.securityEvent.create({
        data: {
          userId: credential.userId,
          eventType: 'WEBAUTHN_REPLAY_DETECTED',
          severity: 'HIGH',
          details: { credentialId: credential.id, expectedCounter: credential.counter, receivedCounter: counter },
          ipAddress: event.requestContext.identity?.sourceIp,
          createdAt: new Date()
        }
      });

      return { statusCode: 401, body: JSON.stringify({ error: 'Replay attack detected' }) };
    }

    // Atualizar counter
    await prisma.webauthnCredential.update({
      where: { id: credential.id },
      data: { counter, lastUsedAt: new Date() }
    });

    // Gerar token de sessão
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const sessionExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 horas

    await prisma.session.create({
      data: {
        userId: credential.userId,
        token: sessionToken,
        expiresAt: sessionExpiry,
        authMethod: 'WEBAUTHN',
        ipAddress: event.requestContext.identity?.sourceIp,
        userAgent: event.headers['User-Agent']
      }
    });

    // Registrar login bem-sucedido
    await prisma.securityEvent.create({
      data: {
        userId: credential.userId,
        eventType: 'WEBAUTHN_AUTH_SUCCESS',
        severity: 'INFO',
        details: { credentialId: credential.id, deviceName: credential.deviceName },
        ipAddress: event.requestContext.identity?.sourceIp,
        createdAt: new Date()
      }
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        sessionToken,
        expiresAt: sessionExpiry.toISOString(),
        user: {
          id: credential.user.id,
          email: credential.user.email,
          name: credential.user.name,
          role: credential.user.role,
          organizationId: credential.user.organizationId,
          organizationName: credential.user.organization.name
        }
      })
    };
  } catch (error) {
    console.error('Assertion verification error:', error);
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid assertion' }) };
  }
}
