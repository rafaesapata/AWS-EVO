-- CreateTable
CREATE TABLE "organizations" (
    "id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "organizations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "profiles" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "full_name" TEXT,
    "avatar_url" TEXT,
    "role" TEXT DEFAULT 'user',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "aws_credentials" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT,
    "account_name" TEXT,
    "access_key_id" TEXT,
    "secret_access_key" TEXT,
    "role_arn" TEXT,
    "external_id" TEXT,
    "session_token" TEXT,
    "regions" TEXT[],
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "aws_credentials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "aws_accounts" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT NOT NULL,
    "account_name" TEXT NOT NULL,
    "email" TEXT,
    "status" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "aws_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "findings" (
    "id" UUID NOT NULL,
    "organization_id" UUID,
    "event_id" TEXT,
    "event_name" TEXT,
    "event_time" TIMESTAMPTZ(6),
    "user_identity" JSONB,
    "severity" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "details" JSONB NOT NULL,
    "ai_analysis" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "source" TEXT,
    "resource_id" TEXT,
    "resource_arn" TEXT,
    "scan_type" TEXT,
    "service" TEXT,
    "category" TEXT,
    "compliance" TEXT[],
    "remediation" TEXT,
    "risk_vector" TEXT,
    "evidence" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "findings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "security_scans" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" UUID NOT NULL,
    "scan_type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "scan_config" JSONB,
    "results" JSONB,
    "findings_count" INTEGER,
    "critical_count" INTEGER,
    "high_count" INTEGER,
    "medium_count" INTEGER,
    "low_count" INTEGER,
    "started_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "security_scans_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "compliance_checks" (
    "id" UUID NOT NULL,
    "scan_id" UUID NOT NULL,
    "framework" TEXT NOT NULL,
    "control_id" TEXT NOT NULL,
    "control_name" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "evidence" JSONB,
    "remediation_steps" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "compliance_checks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "guardduty_findings" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" UUID NOT NULL,
    "finding_id" TEXT NOT NULL,
    "finding_type" TEXT NOT NULL,
    "severity" DOUBLE PRECISION NOT NULL,
    "severity_label" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "resource_type" TEXT,
    "resource_id" TEXT,
    "region" TEXT NOT NULL,
    "service" TEXT NOT NULL,
    "action" JSONB,
    "evidence" JSONB,
    "first_seen" TEXT,
    "last_seen" TEXT,
    "count" INTEGER NOT NULL DEFAULT 1,
    "status" TEXT NOT NULL DEFAULT 'active',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "guardduty_findings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "security_posture" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "overall_score" DOUBLE PRECISION NOT NULL,
    "critical_findings" INTEGER NOT NULL,
    "high_findings" INTEGER NOT NULL,
    "medium_findings" INTEGER NOT NULL,
    "low_findings" INTEGER NOT NULL,
    "compliance_score" DOUBLE PRECISION,
    "risk_level" TEXT NOT NULL,
    "calculated_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "security_posture_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "background_jobs" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "job_type" TEXT NOT NULL,
    "job_name" TEXT NOT NULL,
    "schedule" TEXT,
    "parameters" JSONB,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "result" JSONB,
    "error" TEXT,
    "started_at" TIMESTAMPTZ(6),
    "completed_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "background_jobs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "knowledge_base_articles" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "author_id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "category" TEXT,
    "tags" TEXT[],
    "status" TEXT NOT NULL DEFAULT 'draft',
    "views" INTEGER NOT NULL DEFAULT 0,
    "helpful_count" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "knowledge_base_articles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "licenses" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "license_key" TEXT NOT NULL,
    "customer_id" TEXT,
    "plan_type" TEXT NOT NULL,
    "max_accounts" INTEGER NOT NULL,
    "max_users" INTEGER NOT NULL,
    "features" TEXT[],
    "valid_from" TIMESTAMPTZ(6) NOT NULL,
    "valid_until" TIMESTAMPTZ(6) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "licenses_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "webauthn_credentials" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "credential_id" TEXT NOT NULL,
    "public_key" TEXT NOT NULL,
    "counter" INTEGER NOT NULL DEFAULT 0,
    "device_name" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "last_used_at" TIMESTAMPTZ(6),

    CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "communication_logs" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "channel" TEXT NOT NULL,
    "recipient" TEXT NOT NULL,
    "subject" TEXT,
    "message" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "metadata" JSONB,
    "sent_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "communication_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "daily_costs" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "service" TEXT NOT NULL,
    "cost" DOUBLE PRECISION NOT NULL,
    "usage" DOUBLE PRECISION,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "daily_costs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "waste_detections" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT NOT NULL,
    "resource_id" TEXT NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_name" TEXT,
    "region" TEXT NOT NULL,
    "waste_type" TEXT NOT NULL,
    "confidence" DOUBLE PRECISION NOT NULL,
    "estimated_monthly_cost" DOUBLE PRECISION NOT NULL,
    "estimated_savings" DOUBLE PRECISION NOT NULL,
    "metrics" JSONB,
    "recommendation" TEXT NOT NULL,
    "detected_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "waste_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "drift_detections" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" TEXT NOT NULL,
    "resource_id" TEXT NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_name" TEXT,
    "drift_type" TEXT NOT NULL,
    "detected_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "severity" TEXT NOT NULL,
    "diff" JSONB,
    "expected_state" JSONB,
    "actual_state" JSONB,

    CONSTRAINT "drift_detections_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "drift_detection_history" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "total_drifts" INTEGER NOT NULL,
    "created_count" INTEGER NOT NULL,
    "modified_count" INTEGER NOT NULL,
    "deleted_count" INTEGER NOT NULL,
    "critical_count" INTEGER NOT NULL,
    "high_count" INTEGER NOT NULL,
    "execution_time_seconds" DOUBLE PRECISION NOT NULL,
    "message" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "drift_detection_history_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "resource_inventory" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" TEXT NOT NULL,
    "resource_id" TEXT NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_name" TEXT,
    "region" TEXT NOT NULL,
    "metadata" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "resource_inventory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "compliance_violations" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT NOT NULL,
    "framework" TEXT NOT NULL,
    "control_id" TEXT NOT NULL,
    "resource_id" TEXT,
    "resource_type" TEXT,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "severity" TEXT NOT NULL,
    "description" TEXT,
    "detected_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "resolved_at" TIMESTAMPTZ(6),

    CONSTRAINT "compliance_violations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "alerts" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "rule_id" UUID,
    "severity" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "metadata" JSONB,
    "triggered_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "acknowledged_at" TIMESTAMPTZ(6),
    "resolved_at" TIMESTAMPTZ(6),

    CONSTRAINT "alerts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "alert_rules" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "rule_type" TEXT NOT NULL,
    "condition" JSONB NOT NULL,
    "threshold" DOUBLE PRECISION,
    "severity" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "notification_channels" TEXT[],
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "alert_rules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "monitored_endpoints" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "timeout" INTEGER NOT NULL DEFAULT 5000,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "alert_on_failure" BOOLEAN NOT NULL DEFAULT true,
    "last_status" TEXT,
    "last_checked_at" TIMESTAMPTZ(6),
    "last_response_time" INTEGER,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "monitored_endpoints_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "endpoint_check_history" (
    "id" UUID NOT NULL,
    "endpoint_id" UUID NOT NULL,
    "status" TEXT NOT NULL,
    "status_code" INTEGER,
    "response_time" INTEGER NOT NULL,
    "error" TEXT,
    "checked_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "endpoint_check_history_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "iam_behavior_anomalies" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "account_id" TEXT NOT NULL,
    "user_name" TEXT NOT NULL,
    "anomaly_type" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "evidence" JSONB,
    "detected_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "iam_behavior_anomalies_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jira_integrations" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "base_url" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "api_token" TEXT NOT NULL,
    "project_key" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "jira_integrations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "jira_tickets" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "finding_id" UUID,
    "jira_key" TEXT NOT NULL,
    "jira_id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "jira_tickets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "external_ids" (
    "id" UUID NOT NULL,
    "external_id" TEXT NOT NULL,
    "used" BOOLEAN NOT NULL DEFAULT false,
    "used_by" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "external_ids_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notification_settings" (
    "id" UUID NOT NULL,
    "userId" UUID NOT NULL,
    "email_enabled" BOOLEAN NOT NULL DEFAULT true,
    "webhook_enabled" BOOLEAN NOT NULL DEFAULT false,
    "slack_enabled" BOOLEAN NOT NULL DEFAULT false,
    "security_alerts" BOOLEAN NOT NULL DEFAULT true,
    "cost_alerts" BOOLEAN NOT NULL DEFAULT true,
    "compliance_alerts" BOOLEAN NOT NULL DEFAULT true,
    "drift_alerts" BOOLEAN NOT NULL DEFAULT true,
    "weekly_reports" BOOLEAN NOT NULL DEFAULT true,
    "monthly_reports" BOOLEAN NOT NULL DEFAULT true,
    "webhook_url" TEXT,
    "slack_webhook_url" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "notification_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "report_exports" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "report_type" TEXT NOT NULL,
    "format" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "file_url" TEXT,
    "file_size" INTEGER,
    "parameters" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMPTZ(6),

    CONSTRAINT "report_exports_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cloudtrail_fetches" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" TEXT NOT NULL,
    "region" TEXT NOT NULL,
    "start_time" TIMESTAMPTZ(6) NOT NULL,
    "end_time" TIMESTAMPTZ(6) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "events_count" INTEGER,
    "error_message" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMPTZ(6),

    CONSTRAINT "cloudtrail_fetches_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL,
    "email" TEXT NOT NULL,
    "full_name" TEXT,
    "avatar_url" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "user_id" UUID,
    "action" TEXT NOT NULL,
    "resource_type" TEXT,
    "resource_id" TEXT,
    "details" JSONB,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tv_display_tokens" (
    "id" UUID NOT NULL,
    "token" TEXT NOT NULL,
    "organization_id" UUID NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "tv_display_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tv_token_usage" (
    "id" UUID NOT NULL,
    "token_id" UUID NOT NULL,
    "used_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ip_address" TEXT,

    CONSTRAINT "tv_token_usage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tv_sessions" (
    "id" UUID NOT NULL,
    "token_id" UUID NOT NULL,
    "session_data" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "tv_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "security_events" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "event_type" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "metadata" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "security_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "security_findings" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "finding_type" TEXT NOT NULL,
    "severity" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "resource_id" TEXT,
    "status" TEXT NOT NULL DEFAULT 'open',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "security_findings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "dashboards" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "config" JSONB,
    "is_default" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "dashboards_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "webauthn_challenges" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "challenge" TEXT NOT NULL,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "sessions" (
    "id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "session_token" TEXT NOT NULL,
    "expires_at" TIMESTAMPTZ(6) NOT NULL,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_events" (
    "id" UUID NOT NULL,
    "event_type" TEXT NOT NULL,
    "payload" JSONB,
    "processed" BOOLEAN NOT NULL DEFAULT false,
    "processed_at" TIMESTAMPTZ(6),
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "system_events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "cost_optimizations" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" TEXT NOT NULL,
    "resource_type" TEXT NOT NULL,
    "resource_id" TEXT NOT NULL,
    "optimization_type" TEXT NOT NULL,
    "potential_savings" DOUBLE PRECISION NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "cost_optimizations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "copilot_interactions" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "user_id" UUID,
    "query" TEXT NOT NULL,
    "response" TEXT NOT NULL,
    "context" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "copilot_interactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "compliance_scans" (
    "id" UUID NOT NULL,
    "organization_id" UUID NOT NULL,
    "aws_account_id" TEXT NOT NULL,
    "framework" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "results" JSONB,
    "created_at" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completed_at" TIMESTAMPTZ(6),

    CONSTRAINT "compliance_scans_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "organizations_slug_key" ON "organizations"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "profiles_user_id_organization_id_key" ON "profiles"("user_id", "organization_id");

-- CreateIndex
CREATE UNIQUE INDEX "aws_accounts_organization_id_account_id_key" ON "aws_accounts"("organization_id", "account_id");

-- CreateIndex
CREATE INDEX "findings_status_idx" ON "findings"("status");

-- CreateIndex
CREATE INDEX "findings_severity_idx" ON "findings"("severity");

-- CreateIndex
CREATE INDEX "findings_event_time_idx" ON "findings"("event_time");

-- CreateIndex
CREATE INDEX "findings_organization_id_idx" ON "findings"("organization_id");

-- CreateIndex
CREATE INDEX "security_scans_organization_id_idx" ON "security_scans"("organization_id");

-- CreateIndex
CREATE INDEX "security_scans_status_idx" ON "security_scans"("status");

-- CreateIndex
CREATE INDEX "compliance_checks_scan_id_idx" ON "compliance_checks"("scan_id");

-- CreateIndex
CREATE INDEX "compliance_checks_framework_idx" ON "compliance_checks"("framework");

-- CreateIndex
CREATE INDEX "compliance_checks_status_idx" ON "compliance_checks"("status");

-- CreateIndex
CREATE INDEX "guardduty_findings_organization_id_idx" ON "guardduty_findings"("organization_id");

-- CreateIndex
CREATE INDEX "guardduty_findings_status_idx" ON "guardduty_findings"("status");

-- CreateIndex
CREATE INDEX "guardduty_findings_severity_label_idx" ON "guardduty_findings"("severity_label");

-- CreateIndex
CREATE UNIQUE INDEX "guardduty_findings_aws_account_id_finding_id_key" ON "guardduty_findings"("aws_account_id", "finding_id");

-- CreateIndex
CREATE INDEX "security_posture_organization_id_idx" ON "security_posture"("organization_id");

-- CreateIndex
CREATE INDEX "security_posture_calculated_at_idx" ON "security_posture"("calculated_at");

-- CreateIndex
CREATE INDEX "background_jobs_organization_id_idx" ON "background_jobs"("organization_id");

-- CreateIndex
CREATE INDEX "background_jobs_status_idx" ON "background_jobs"("status");

-- CreateIndex
CREATE INDEX "background_jobs_job_type_idx" ON "background_jobs"("job_type");

-- CreateIndex
CREATE INDEX "knowledge_base_articles_organization_id_idx" ON "knowledge_base_articles"("organization_id");

-- CreateIndex
CREATE INDEX "knowledge_base_articles_status_idx" ON "knowledge_base_articles"("status");

-- CreateIndex
CREATE INDEX "knowledge_base_articles_category_idx" ON "knowledge_base_articles"("category");

-- CreateIndex
CREATE UNIQUE INDEX "licenses_license_key_key" ON "licenses"("license_key");

-- CreateIndex
CREATE INDEX "licenses_organization_id_idx" ON "licenses"("organization_id");

-- CreateIndex
CREATE INDEX "licenses_is_active_idx" ON "licenses"("is_active");

-- CreateIndex
CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "webauthn_credentials"("credential_id");

-- CreateIndex
CREATE INDEX "webauthn_credentials_user_id_idx" ON "webauthn_credentials"("user_id");

-- CreateIndex
CREATE INDEX "communication_logs_organization_id_idx" ON "communication_logs"("organization_id");

-- CreateIndex
CREATE INDEX "communication_logs_channel_idx" ON "communication_logs"("channel");

-- CreateIndex
CREATE INDEX "communication_logs_status_idx" ON "communication_logs"("status");

-- CreateIndex
CREATE INDEX "daily_costs_organization_id_idx" ON "daily_costs"("organization_id");

-- CreateIndex
CREATE INDEX "daily_costs_date_idx" ON "daily_costs"("date");

-- CreateIndex
CREATE UNIQUE INDEX "daily_costs_account_id_date_service_key" ON "daily_costs"("account_id", "date", "service");

-- CreateIndex
CREATE INDEX "waste_detections_organization_id_idx" ON "waste_detections"("organization_id");

-- CreateIndex
CREATE INDEX "waste_detections_waste_type_idx" ON "waste_detections"("waste_type");

-- CreateIndex
CREATE INDEX "waste_detections_detected_at_idx" ON "waste_detections"("detected_at");

-- CreateIndex
CREATE INDEX "drift_detections_organization_id_idx" ON "drift_detections"("organization_id");

-- CreateIndex
CREATE INDEX "drift_detections_drift_type_idx" ON "drift_detections"("drift_type");

-- CreateIndex
CREATE INDEX "drift_detections_severity_idx" ON "drift_detections"("severity");

-- CreateIndex
CREATE INDEX "drift_detections_detected_at_idx" ON "drift_detections"("detected_at");

-- CreateIndex
CREATE INDEX "drift_detection_history_organization_id_idx" ON "drift_detection_history"("organization_id");

-- CreateIndex
CREATE INDEX "drift_detection_history_created_at_idx" ON "drift_detection_history"("created_at");

-- CreateIndex
CREATE INDEX "resource_inventory_organization_id_idx" ON "resource_inventory"("organization_id");

-- CreateIndex
CREATE INDEX "resource_inventory_resource_type_idx" ON "resource_inventory"("resource_type");

-- CreateIndex
CREATE UNIQUE INDEX "resource_inventory_aws_account_id_resource_id_region_key" ON "resource_inventory"("aws_account_id", "resource_id", "region");

-- CreateIndex
CREATE INDEX "compliance_violations_organization_id_idx" ON "compliance_violations"("organization_id");

-- CreateIndex
CREATE INDEX "compliance_violations_framework_idx" ON "compliance_violations"("framework");

-- CreateIndex
CREATE INDEX "compliance_violations_status_idx" ON "compliance_violations"("status");

-- CreateIndex
CREATE INDEX "compliance_violations_detected_at_idx" ON "compliance_violations"("detected_at");

-- CreateIndex
CREATE INDEX "alerts_organization_id_idx" ON "alerts"("organization_id");

-- CreateIndex
CREATE INDEX "alerts_severity_idx" ON "alerts"("severity");

-- CreateIndex
CREATE INDEX "alerts_triggered_at_idx" ON "alerts"("triggered_at");

-- CreateIndex
CREATE INDEX "alert_rules_organization_id_idx" ON "alert_rules"("organization_id");

-- CreateIndex
CREATE INDEX "alert_rules_is_active_idx" ON "alert_rules"("is_active");

-- CreateIndex
CREATE INDEX "monitored_endpoints_organization_id_idx" ON "monitored_endpoints"("organization_id");

-- CreateIndex
CREATE INDEX "monitored_endpoints_is_active_idx" ON "monitored_endpoints"("is_active");

-- CreateIndex
CREATE INDEX "endpoint_check_history_endpoint_id_idx" ON "endpoint_check_history"("endpoint_id");

-- CreateIndex
CREATE INDEX "endpoint_check_history_checked_at_idx" ON "endpoint_check_history"("checked_at");

-- CreateIndex
CREATE INDEX "iam_behavior_anomalies_organization_id_idx" ON "iam_behavior_anomalies"("organization_id");

-- CreateIndex
CREATE INDEX "iam_behavior_anomalies_severity_idx" ON "iam_behavior_anomalies"("severity");

-- CreateIndex
CREATE INDEX "iam_behavior_anomalies_detected_at_idx" ON "iam_behavior_anomalies"("detected_at");

-- CreateIndex
CREATE INDEX "jira_integrations_organization_id_idx" ON "jira_integrations"("organization_id");

-- CreateIndex
CREATE INDEX "jira_tickets_organization_id_idx" ON "jira_tickets"("organization_id");

-- CreateIndex
CREATE INDEX "jira_tickets_finding_id_idx" ON "jira_tickets"("finding_id");

-- CreateIndex
CREATE UNIQUE INDEX "external_ids_external_id_key" ON "external_ids"("external_id");

-- CreateIndex
CREATE INDEX "external_ids_used_idx" ON "external_ids"("used");

-- CreateIndex
CREATE INDEX "external_ids_created_at_idx" ON "external_ids"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "notification_settings_userId_key" ON "notification_settings"("userId");

-- CreateIndex
CREATE INDEX "report_exports_organization_id_idx" ON "report_exports"("organization_id");

-- CreateIndex
CREATE INDEX "report_exports_status_idx" ON "report_exports"("status");

-- CreateIndex
CREATE INDEX "cloudtrail_fetches_organization_id_idx" ON "cloudtrail_fetches"("organization_id");

-- CreateIndex
CREATE INDEX "cloudtrail_fetches_status_idx" ON "cloudtrail_fetches"("status");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE INDEX "audit_logs_organization_id_idx" ON "audit_logs"("organization_id");

-- CreateIndex
CREATE INDEX "audit_logs_user_id_idx" ON "audit_logs"("user_id");

-- CreateIndex
CREATE INDEX "audit_logs_action_idx" ON "audit_logs"("action");

-- CreateIndex
CREATE INDEX "audit_logs_created_at_idx" ON "audit_logs"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "tv_display_tokens_token_key" ON "tv_display_tokens"("token");

-- CreateIndex
CREATE INDEX "tv_display_tokens_organization_id_idx" ON "tv_display_tokens"("organization_id");

-- CreateIndex
CREATE INDEX "tv_display_tokens_token_idx" ON "tv_display_tokens"("token");

-- CreateIndex
CREATE INDEX "tv_token_usage_token_id_idx" ON "tv_token_usage"("token_id");

-- CreateIndex
CREATE INDEX "tv_sessions_token_id_idx" ON "tv_sessions"("token_id");

-- CreateIndex
CREATE INDEX "security_events_organization_id_idx" ON "security_events"("organization_id");

-- CreateIndex
CREATE INDEX "security_events_event_type_idx" ON "security_events"("event_type");

-- CreateIndex
CREATE INDEX "security_events_severity_idx" ON "security_events"("severity");

-- CreateIndex
CREATE INDEX "security_findings_organization_id_idx" ON "security_findings"("organization_id");

-- CreateIndex
CREATE INDEX "security_findings_severity_idx" ON "security_findings"("severity");

-- CreateIndex
CREATE INDEX "security_findings_status_idx" ON "security_findings"("status");

-- CreateIndex
CREATE INDEX "dashboards_organization_id_idx" ON "dashboards"("organization_id");

-- CreateIndex
CREATE INDEX "webauthn_challenges_user_id_idx" ON "webauthn_challenges"("user_id");

-- CreateIndex
CREATE INDEX "webauthn_challenges_challenge_idx" ON "webauthn_challenges"("challenge");

-- CreateIndex
CREATE UNIQUE INDEX "sessions_session_token_key" ON "sessions"("session_token");

-- CreateIndex
CREATE INDEX "sessions_user_id_idx" ON "sessions"("user_id");

-- CreateIndex
CREATE INDEX "sessions_session_token_idx" ON "sessions"("session_token");

-- CreateIndex
CREATE INDEX "system_events_processed_idx" ON "system_events"("processed");

-- CreateIndex
CREATE INDEX "system_events_event_type_idx" ON "system_events"("event_type");

-- CreateIndex
CREATE INDEX "system_events_created_at_idx" ON "system_events"("created_at");

-- CreateIndex
CREATE INDEX "cost_optimizations_organization_id_idx" ON "cost_optimizations"("organization_id");

-- CreateIndex
CREATE INDEX "cost_optimizations_aws_account_id_idx" ON "cost_optimizations"("aws_account_id");

-- CreateIndex
CREATE INDEX "copilot_interactions_organization_id_idx" ON "copilot_interactions"("organization_id");

-- CreateIndex
CREATE INDEX "copilot_interactions_user_id_idx" ON "copilot_interactions"("user_id");

-- CreateIndex
CREATE INDEX "compliance_scans_organization_id_idx" ON "compliance_scans"("organization_id");

-- CreateIndex
CREATE INDEX "compliance_scans_aws_account_id_idx" ON "compliance_scans"("aws_account_id");

-- AddForeignKey
ALTER TABLE "profiles" ADD CONSTRAINT "profiles_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "aws_credentials" ADD CONSTRAINT "aws_credentials_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "aws_accounts" ADD CONSTRAINT "aws_accounts_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "findings" ADD CONSTRAINT "findings_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "security_scans" ADD CONSTRAINT "security_scans_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "security_scans" ADD CONSTRAINT "security_scans_aws_account_id_fkey" FOREIGN KEY ("aws_account_id") REFERENCES "aws_credentials"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_checks" ADD CONSTRAINT "compliance_checks_scan_id_fkey" FOREIGN KEY ("scan_id") REFERENCES "security_scans"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "guardduty_findings" ADD CONSTRAINT "guardduty_findings_aws_account_id_fkey" FOREIGN KEY ("aws_account_id") REFERENCES "aws_credentials"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "background_jobs" ADD CONSTRAINT "background_jobs_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "knowledge_base_articles" ADD CONSTRAINT "knowledge_base_articles_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "licenses" ADD CONSTRAINT "licenses_organization_id_fkey" FOREIGN KEY ("organization_id") REFERENCES "organizations"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "alerts" ADD CONSTRAINT "alerts_rule_id_fkey" FOREIGN KEY ("rule_id") REFERENCES "alert_rules"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "endpoint_check_history" ADD CONSTRAINT "endpoint_check_history_endpoint_id_fkey" FOREIGN KEY ("endpoint_id") REFERENCES "monitored_endpoints"("id") ON DELETE CASCADE ON UPDATE CASCADE;

