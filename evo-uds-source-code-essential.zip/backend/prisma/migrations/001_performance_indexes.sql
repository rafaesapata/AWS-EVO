-- Performance Optimization Indexes
-- Critical indexes for query performance improvement

-- Findings table indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_org_severity_status 
ON findings (organization_id, severity, status, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_org_created 
ON findings (organization_id, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_severity_status 
ON findings (severity, status) WHERE organization_id IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_search 
ON findings USING gin(to_tsvector('portuguese', description));

-- Security scans indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_security_scans_org_status 
ON security_scans (organization_id, status, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_security_scans_aws_account 
ON security_scans (aws_account_id, status, created_at DESC);

-- AWS credentials indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_aws_credentials_org_active 
ON aws_credentials (organization_id, is_active);

-- Background jobs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_background_jobs_org_status 
ON background_jobs (organization_id, status, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_background_jobs_type_status 
ON background_jobs (job_type, status);

-- GuardDuty findings indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_guardduty_org_severity 
ON guardduty_findings (organization_id, severity_label, detected_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_guardduty_account_status 
ON guardduty_findings (aws_account_id, status);

-- Compliance checks indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_compliance_scan_framework 
ON compliance_checks (scan_id, framework, status);

-- Daily costs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_daily_costs_org_date 
ON daily_costs (organization_id, date DESC, service);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_daily_costs_account_date 
ON daily_costs (account_id, date DESC);

-- Waste detection indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_waste_detection_org_type 
ON waste_detections (organization_id, waste_type, detected_at DESC);

-- Knowledge base indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_kb_articles_org_status 
ON knowledge_base_articles (organization_id, status, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_kb_articles_category 
ON knowledge_base_articles (category, status) WHERE organization_id IS NOT NULL;

-- Alerts indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_org_severity 
ON alerts (organization_id, severity, triggered_at DESC);

-- Communication logs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_comm_logs_org_channel 
ON communication_logs (organization_id, channel, sent_at DESC);

-- Profiles indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_profiles_user_org 
ON profiles (user_id, organization_id);

-- Partial indexes for active records
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_active 
ON findings (organization_id, created_at DESC) WHERE status != 'resolved';

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_aws_credentials_active 
ON aws_credentials (organization_id) WHERE is_active = true;

-- Composite indexes for common query patterns
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_findings_complex_filter 
ON findings (organization_id, severity, status, service, created_at DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_security_scans_complete 
ON security_scans (organization_id, scan_type, status, started_at DESC);