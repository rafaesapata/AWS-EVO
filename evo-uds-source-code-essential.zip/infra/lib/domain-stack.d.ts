import * as cdk from 'aws-cdk-lib';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
import { Construct } from 'constructs';
export interface DomainStackProps extends cdk.StackProps {
    distribution: cloudfront.Distribution;
    api: apigateway.RestApi;
    domainName: string;
    hostedZoneId: string;
    hostedZoneName: string;
}
export declare class DomainStack extends cdk.Stack {
    readonly certificate: acm.Certificate;
    readonly domainName: string;
    constructor(scope: Construct, id: string, props: DomainStackProps);
}
