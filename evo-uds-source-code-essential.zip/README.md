# EVO UDS - AWS Cost Optimization Platform

## Project Overview

EVO UDS is a comprehensive AWS cost optimization and security analysis platform built with modern web technologies and AWS native architecture.

## Architecture

- **Frontend**: React + TypeScript + Vite
- **Backend**: AWS Lambda + API Gateway
- **Database**: AWS RDS PostgreSQL
- **Authentication**: AWS Cognito
- **Infrastructure**: AWS CDK
- **Deployment**: Fully automated with AWS CloudFormation

## How to develop this application

**Local Development**

Clone this repository and install dependencies:

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How to deploy this project?

The project includes a fully automated deployment system:

```bash
# Deploy to development environment
npm run deploy:dev

# Deploy to staging environment  
npm run deploy:staging

# Deploy to production environment
npm run deploy:prod
```

## Features

- **Cost Optimization**: AI-powered AWS cost analysis and recommendations
- **Security Analysis**: Comprehensive security auditing and compliance checking
- **Multi-Account Support**: Manage multiple AWS accounts from a single dashboard
- **Real-time Monitoring**: Live cost and performance monitoring
- **Automated Reporting**: Scheduled reports and alerts
- **Role-based Access**: Secure multi-tenant architecture

## Technology Stack

- React 18 + TypeScript
- AWS Lambda + API Gateway
- AWS RDS PostgreSQL
- AWS Cognito Authentication
- AWS CDK Infrastructure as Code
- Tailwind CSS + Radix UI Components
