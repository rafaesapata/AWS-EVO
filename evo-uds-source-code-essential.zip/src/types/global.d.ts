// Global type declarations for AWS integration

declare global {
  interface Window {
    // AWS integration globals can be added here if needed
  }
}

export {};
