import { AnomalyDashboard } from "@/components/dashboard/AnomalyDashboard";

const AnomalyDetection = () => {
  return (
    <div className="container mx-auto p-6 space-y-6">
      <AnomalyDashboard />
    </div>
  );
};

export default AnomalyDetection;
