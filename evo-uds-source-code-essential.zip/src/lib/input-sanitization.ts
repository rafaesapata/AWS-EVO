/**
 * Comprehensive Input Sanitization System
 * Provides protection against XSS, injection attacks, and malicious input
 */

import DOMPurify from 'isomorphic-dompurify';

export interface SanitizationOptions {
  allowHtml?: boolean;
  allowedTags?: string[];
  allowedAttributes?: string[];
  maxLength?: number;
  trimWhitespace?: boolean;
  removeEmptyLines?: boolean;
  normalizeUnicode?: boolean;
  preventXSS?: boolean;
  preventSQLInjection?: boolean;
  preventCommandInjection?: boolean;
}

export interface SanitizationResult {
  sanitized: string;
  wasModified: boolean;
  removedContent: string[];
  warnings: string[];
}

/**
 * Input Sanitizer Class
 */
export class InputSanitizer {
  private static readonly XSS_PATTERNS = [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe\b[^>]*>/gi,
    /<object\b[^>]*>/gi,
    /<embed\b[^>]*>/gi,
    /<link\b[^>]*>/gi,
    /<meta\b[^>]*>/gi,
    /expression\s*\(/gi,
    /vbscript:/gi,
    /data:text\/html/gi,
  ];

  private static readonly SQL_INJECTION_PATTERNS = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)/gi,
    /('|(\\')|(;)|(\\;)|(\|)|(\*)|(%)|(<)|(>)|(\^)|(\[)|(\])|(\{)|(\})|(\()|(\))|(\+)|(\=))/gi,
    /((\%3D)|(=))[^\n]*((\%27)|(\')|(\-\-)|(\%3B)|(;))/gi,
    /\w*((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/gi,
  ];

  private static readonly COMMAND_INJECTION_PATTERNS = [
    /[;&|`$(){}[\]\\]/g,
    /\b(cat|ls|pwd|whoami|id|uname|ps|netstat|ifconfig|ping|curl|wget|nc|ncat|telnet|ssh|ftp|scp|rsync)\b/gi,
    /(\||;|&|`|\$\(|\${)/g,
  ];

  private static readonly DANGEROUS_PROTOCOLS = [
    'javascript:',
    'vbscript:',
    'data:text/html',
    'data:application/',
    'file:',
    'ftp:',
  ];

  /**
   * Sanitize a single string input
   */
  static sanitizeString(
    input: string,
    options: SanitizationOptions = {}
  ): SanitizationResult {
    const {
      allowHtml = false,
      allowedTags = [],
      allowedAttributes = [],
      maxLength,
      trimWhitespace = true,
      removeEmptyLines = false,
      normalizeUnicode = true,
      preventXSS = true,
      preventSQLInjection = true,
      preventCommandInjection = true,
    } = options;

    let sanitized = input;
    const removedContent: string[] = [];
    const warnings: string[] = [];
    let wasModified = false;

    // Normalize unicode
    if (normalizeUnicode) {
      const normalized = sanitized.normalize('NFC');
      if (normalized !== sanitized) {
        sanitized = normalized;
        wasModified = true;
      }
    }

    // Trim whitespace
    if (trimWhitespace) {
      const trimmed = sanitized.trim();
      if (trimmed !== sanitized) {
        sanitized = trimmed;
        wasModified = true;
      }
    }

    // Remove empty lines
    if (removeEmptyLines) {
      const withoutEmptyLines = sanitized.replace(/^\s*[\r\n]/gm, '');
      if (withoutEmptyLines !== sanitized) {
        sanitized = withoutEmptyLines;
        wasModified = true;
      }
    }

    // Length limit
    if (maxLength && sanitized.length > maxLength) {
      sanitized = sanitized.substring(0, maxLength);
      wasModified = true;
      warnings.push(`Input truncated to ${maxLength} characters`);
    }

    // XSS Prevention
    if (preventXSS) {
      const xssResult = this.removeXSS(sanitized, allowHtml, allowedTags, allowedAttributes);
      if (xssResult.wasModified) {
        sanitized = xssResult.sanitized;
        wasModified = true;
        removedContent.push(...xssResult.removedContent);
        warnings.push(...xssResult.warnings);
      }
    }

    // SQL Injection Prevention
    if (preventSQLInjection) {
      const sqlResult = this.removeSQLInjection(sanitized);
      if (sqlResult.wasModified) {
        sanitized = sqlResult.sanitized;
        wasModified = true;
        removedContent.push(...sqlResult.removedContent);
        warnings.push(...sqlResult.warnings);
      }
    }

    // Command Injection Prevention
    if (preventCommandInjection) {
      const cmdResult = this.removeCommandInjection(sanitized);
      if (cmdResult.wasModified) {
        sanitized = cmdResult.sanitized;
        wasModified = true;
        removedContent.push(...cmdResult.removedContent);
        warnings.push(...cmdResult.warnings);
      }
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Remove XSS patterns
   */
  private static removeXSS(
    input: string,
    allowHtml: boolean,
    allowedTags: string[],
    allowedAttributes: string[]
  ): SanitizationResult {
    let sanitized = input;
    const removedContent: string[] = [];
    const warnings: string[] = [];
    let wasModified = false;

    if (allowHtml) {
      // Use DOMPurify for HTML sanitization
      const config: any = {};
      
      if (allowedTags.length > 0) {
        config.ALLOWED_TAGS = allowedTags;
      }
      
      if (allowedAttributes.length > 0) {
        config.ALLOWED_ATTR = allowedAttributes;
      }

      const purified = DOMPurify.sanitize(sanitized, config);
      if (purified !== sanitized) {
        sanitized = purified;
        wasModified = true;
        warnings.push('HTML content was sanitized');
      }
    } else {
      // Remove all HTML/XSS patterns
      for (const pattern of this.XSS_PATTERNS) {
        const matches = sanitized.match(pattern);
        if (matches) {
          removedContent.push(...matches);
          sanitized = sanitized.replace(pattern, '');
          wasModified = true;
        }
      }

      // Remove dangerous protocols
      for (const protocol of this.DANGEROUS_PROTOCOLS) {
        if (sanitized.toLowerCase().includes(protocol)) {
          sanitized = sanitized.replace(new RegExp(protocol, 'gi'), '');
          wasModified = true;
          warnings.push(`Dangerous protocol removed: ${protocol}`);
        }
      }

      // Encode remaining HTML entities
      sanitized = sanitized
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\//g, '&#x2F;');

      if (sanitized !== input) {
        wasModified = true;
      }
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Remove SQL injection patterns
   */
  private static removeSQLInjection(input: string): SanitizationResult {
    let sanitized = input;
    const removedContent: string[] = [];
    const warnings: string[] = [];
    let wasModified = false;

    for (const pattern of this.SQL_INJECTION_PATTERNS) {
      const matches = sanitized.match(pattern);
      if (matches) {
        removedContent.push(...matches);
        sanitized = sanitized.replace(pattern, '');
        wasModified = true;
        warnings.push('Potential SQL injection pattern removed');
      }
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Remove command injection patterns
   */
  private static removeCommandInjection(input: string): SanitizationResult {
    let sanitized = input;
    const removedContent: string[] = [];
    const warnings: string[] = [];
    let wasModified = false;

    for (const pattern of this.COMMAND_INJECTION_PATTERNS) {
      const matches = sanitized.match(pattern);
      if (matches) {
        removedContent.push(...matches);
        sanitized = sanitized.replace(pattern, '');
        wasModified = true;
        warnings.push('Potential command injection pattern removed');
      }
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Sanitize an object recursively
   */
  static sanitizeObject<T extends Record<string, any>>(
    obj: T,
    options: SanitizationOptions = {}
  ): {
    sanitized: T;
    wasModified: boolean;
    warnings: string[];
  } {
    const sanitized = { ...obj };
    let wasModified = false;
    const warnings: string[] = [];

    const sanitizeValue = (value: any, key: string): any => {
      if (typeof value === 'string') {
        const result = this.sanitizeString(value, options);
        if (result.wasModified) {
          wasModified = true;
          warnings.push(`Field '${key}' was sanitized: ${result.warnings.join(', ')}`);
        }
        return result.sanitized;
      } else if (Array.isArray(value)) {
        return value.map((item, index) => sanitizeValue(item, `${key}[${index}]`));
      } else if (value && typeof value === 'object') {
        const nestedResult = this.sanitizeObject(value, options);
        if (nestedResult.wasModified) {
          wasModified = true;
          warnings.push(...nestedResult.warnings);
        }
        return nestedResult.sanitized;
      }
      return value;
    };

    for (const [key, value] of Object.entries(sanitized)) {
      sanitized[key] = sanitizeValue(value, key);
    }

    return {
      sanitized,
      wasModified,
      warnings,
    };
  }

  /**
   * Validate and sanitize email
   */
  static sanitizeEmail(email: string): SanitizationResult {
    let sanitized = email.toLowerCase().trim();
    const warnings: string[] = [];
    let wasModified = email !== sanitized;

    // Remove dangerous characters
    const dangerousChars = /[<>()[\]\\,;:\s@"]/g;
    const matches = sanitized.match(dangerousChars);
    if (matches) {
      sanitized = sanitized.replace(dangerousChars, '');
      wasModified = true;
      warnings.push('Dangerous characters removed from email');
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(sanitized)) {
      warnings.push('Email format may be invalid after sanitization');
    }

    return {
      sanitized,
      wasModified,
      removedContent: matches || [],
      warnings,
    };
  }

  /**
   * Sanitize URL
   */
  static sanitizeURL(url: string): SanitizationResult {
    let sanitized = url.trim();
    const warnings: string[] = [];
    const removedContent: string[] = [];
    let wasModified = url !== sanitized;

    try {
      const urlObj = new URL(sanitized);
      
      // Check for dangerous protocols
      if (this.DANGEROUS_PROTOCOLS.some(protocol => 
        urlObj.protocol.toLowerCase().startsWith(protocol.replace(':', ''))
      )) {
        sanitized = '';
        wasModified = true;
        warnings.push('Dangerous protocol removed from URL');
        removedContent.push(url);
      } else {
        // Reconstruct URL to normalize it
        const normalizedUrl = urlObj.toString();
        if (normalizedUrl !== sanitized) {
          sanitized = normalizedUrl;
          wasModified = true;
        }
      }
    } catch (error) {
      warnings.push('Invalid URL format');
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Sanitize filename
   */
  static sanitizeFilename(filename: string): SanitizationResult {
    let sanitized = filename.trim();
    const warnings: string[] = [];
    const removedContent: string[] = [];
    let wasModified = filename !== sanitized;

    // Remove path traversal attempts
    const pathTraversal = /\.\./g;
    const matches = sanitized.match(pathTraversal);
    if (matches) {
      sanitized = sanitized.replace(pathTraversal, '');
      wasModified = true;
      removedContent.push(...matches);
      warnings.push('Path traversal patterns removed');
    }

    // Remove dangerous characters
    const dangerousChars = /[<>:"|?*\x00-\x1f]/g;
    const dangerousMatches = sanitized.match(dangerousChars);
    if (dangerousMatches) {
      sanitized = sanitized.replace(dangerousChars, '');
      wasModified = true;
      removedContent.push(...dangerousMatches);
      warnings.push('Dangerous characters removed from filename');
    }

    // Limit length
    if (sanitized.length > 255) {
      const extension = sanitized.substring(sanitized.lastIndexOf('.'));
      sanitized = sanitized.substring(0, 255 - extension.length) + extension;
      wasModified = true;
      warnings.push('Filename truncated to 255 characters');
    }

    return {
      sanitized,
      wasModified,
      removedContent,
      warnings,
    };
  }

  /**
   * Sanitize JSON string
   */
  static sanitizeJSON(jsonString: string): SanitizationResult {
    let sanitized = jsonString.trim();
    const warnings: string[] = [];
    let wasModified = jsonString !== sanitized;

    try {
      // Parse and re-stringify to normalize
      const parsed = JSON.parse(sanitized);
      const objectResult = this.sanitizeObject(parsed, {
        preventXSS: true,
        preventSQLInjection: true,
        preventCommandInjection: true,
      });

      if (objectResult.wasModified) {
        sanitized = JSON.stringify(objectResult.sanitized);
        wasModified = true;
        warnings.push(...objectResult.warnings);
      }
    } catch (error) {
      warnings.push('Invalid JSON format');
    }

    return {
      sanitized,
      wasModified,
      removedContent: [],
      warnings,
    };
  }
}

/**
 * React hook for input sanitization
 */
export function useSanitization() {
  const sanitizeString = useCallback((
    input: string,
    options?: SanitizationOptions
  ) => {
    return InputSanitizer.sanitizeString(input, options);
  }, []);

  const sanitizeObject = useCallback(<T extends Record<string, any>>(
    obj: T,
    options?: SanitizationOptions
  ) => {
    return InputSanitizer.sanitizeObject(obj, options);
  }, []);

  const sanitizeEmail = useCallback((email: string) => {
    return InputSanitizer.sanitizeEmail(email);
  }, []);

  const sanitizeURL = useCallback((url: string) => {
    return InputSanitizer.sanitizeURL(url);
  }, []);

  const sanitizeFilename = useCallback((filename: string) => {
    return InputSanitizer.sanitizeFilename(filename);
  }, []);

  return {
    sanitizeString,
    sanitizeObject,
    sanitizeEmail,
    sanitizeURL,
    sanitizeFilename,
  };
}

/**
 * Sanitization middleware for forms
 */
export function withSanitization<T extends Record<string, any>>(
  formData: T,
  options: SanitizationOptions = {}
): {
  sanitized: T;
  wasModified: boolean;
  warnings: string[];
} {
  return InputSanitizer.sanitizeObject(formData, {
    preventXSS: true,
    preventSQLInjection: true,
    preventCommandInjection: true,
    trimWhitespace: true,
    normalizeUnicode: true,
    ...options,
  });
}

/**
 * Predefined sanitization configurations
 */
export const SANITIZATION_CONFIGS = {
  // Strict sanitization for user input
  STRICT: {
    allowHtml: false,
    preventXSS: true,
    preventSQLInjection: true,
    preventCommandInjection: true,
    trimWhitespace: true,
    normalizeUnicode: true,
    maxLength: 1000,
  },

  // Moderate sanitization for content
  MODERATE: {
    allowHtml: true,
    allowedTags: ['p', 'br', 'strong', 'em', 'u', 'ol', 'ul', 'li'],
    allowedAttributes: ['class'],
    preventXSS: true,
    preventSQLInjection: true,
    preventCommandInjection: true,
    trimWhitespace: true,
    normalizeUnicode: true,
    maxLength: 5000,
  },

  // Lenient sanitization for rich content
  LENIENT: {
    allowHtml: true,
    allowedTags: ['p', 'br', 'strong', 'em', 'u', 'ol', 'ul', 'li', 'a', 'img', 'h1', 'h2', 'h3'],
    allowedAttributes: ['href', 'src', 'alt', 'class', 'id'],
    preventXSS: true,
    preventSQLInjection: false,
    preventCommandInjection: false,
    trimWhitespace: true,
    normalizeUnicode: true,
    maxLength: 10000,
  },

  // Basic sanitization
  BASIC: {
    allowHtml: false,
    preventXSS: true,
    preventSQLInjection: false,
    preventCommandInjection: false,
    trimWhitespace: true,
    normalizeUnicode: true,
  },
} as const;