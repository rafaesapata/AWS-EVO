#!/usr/bin/env node

/**
 * EVO CLI Tool
 * Command-line interface for EVO AWS Security & Cost Auditor
 */

import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = process.env.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

interface CLIConfig {
  apiUrl?: string;
  apiKey?: string;
  organizationId?: string;
}

class EVOCli {
  private supabase;
  private config: CLIConfig = {};

  constructor() {
    this.supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    this.loadConfig();
  }

  private loadConfig() {
    // Load config from file or environment
    this.config = {
      apiUrl: process.env.EVO_API_URL,
      apiKey: process.env.EVO_API_KEY,
      organizationId: process.env.EVO_ORG_ID,
    };
  }

  async login(email: string, password: string) {
    const { data, error } = await this.supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error('❌ Login failed:', error.message);
      process.exit(1);
    }

    console.log('✅ Login successful');
    console.log('Session token:', data.session?.access_token);
  }

  async scanAWS(accountId: string) {
    console.log(`🔍 Starting security scan for account: ${accountId}`);

    const { data, error } = await this.supabase.functions.invoke('security-scan', {
      body: { accountId },
    });

    if (error) {
      console.error('❌ Scan failed:', error.message);
      process.exit(1);
    }

    console.log('✅ Scan completed');
    console.log('Results:', JSON.stringify(data, null, 2));
  }

  async refreshMaterializedViews() {
    console.log('🔄 Refreshing materialized views...');

    const { error } = await this.supabase.rpc('refresh_materialized_views_incremental');

    if (error) {
      console.error('❌ Refresh failed:', error.message);
      process.exit(1);
    }

    console.log('✅ Materialized views refreshed successfully');
  }

  async getCosts(organizationId: string, startDate: string, endDate: string) {
    console.log(`💰 Fetching costs for org ${organizationId}`);

    const { data, error } = await this.supabase
      .from('daily_costs')
      .select('*')
      .eq('organization_id', organizationId)
      .gte('cost_date', startDate)
      .lte('cost_date', endDate)
      .order('cost_date', { ascending: false });

    if (error) {
      console.error('❌ Failed to fetch costs:', error.message);
      process.exit(1);
    }

    console.table(data);
  }

  async exportData(organizationId: string, format: 'json' | 'csv' = 'json') {
    console.log(`📊 Exporting data for org ${organizationId}`);

    const { data, error } = await this.supabase.functions.invoke('generate-excel-report', {
      body: { organizationId, format },
    });

    if (error) {
      console.error('❌ Export failed:', error.message);
      process.exit(1);
    }

    console.log('✅ Data exported successfully');
    console.log('Download URL:', data.url);
  }

  async getSystemHealth() {
    console.log('🏥 Checking system health...');

    const { data, error } = await this.supabase
      .from('system_health_metrics')
      .select('*')
      .gte('recorded_at', new Date(Date.now() - 3600000).toISOString())
      .order('recorded_at', { ascending: false })
      .limit(10);

    if (error) {
      console.error('❌ Failed to fetch health metrics:', error.message);
      process.exit(1);
    }

    console.table(data);
  }

  async getEvents(organizationId: string, limit: number = 10) {
    console.log(`📋 Fetching recent events for org ${organizationId}`);

    const { data, error } = await this.supabase
      .from('system_events')
      .select('*')
      .eq('organization_id', organizationId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('❌ Failed to fetch events:', error.message);
      process.exit(1);
    }

    console.table(data);
  }

  async validateLicense(customerId: string) {
    console.log(`🔐 Validating license for customer: ${customerId}`);

    const { data, error } = await this.supabase.functions.invoke('validate-license', {
      body: { customer_id: customerId },
    });

    if (error) {
      console.error('❌ Validation failed:', error.message);
      process.exit(1);
    }

    console.log('✅ License validation completed');
    console.log('Status:', data.valid ? '✅ Valid' : '❌ Invalid');
    console.log('Details:', JSON.stringify(data, null, 2));
  }

  showHelp() {
    console.log(`
EVO CLI - AWS Security & Cost Auditor Command Line Interface

Usage: evo-cli [command] [options]

Commands:
  login <email> <password>                Login to EVO
  scan <account-id>                       Run security scan
  refresh-views                           Refresh materialized views
  costs <org-id> <start> <end>           Get cost data
  export <org-id> [format]               Export data (json|csv)
  health                                  Check system health
  events <org-id> [limit]                Get recent events
  validate-license <customer-id>          Validate license
  help                                    Show this help

Examples:
  evo-cli login user@example.com password123
  evo-cli scan abc-123-def
  evo-cli costs org-uuid 2024-01-01 2024-01-31
  evo-cli export org-uuid csv
  evo-cli validate-license cust-12345

Environment Variables:
  VITE_SUPABASE_URL                      Supabase project URL
  SUPABASE_SERVICE_ROLE_KEY              Service role key (for admin operations)
  EVO_API_URL                            EVO API endpoint
  EVO_API_KEY                            API authentication key
  EVO_ORG_ID                             Default organization ID
    `);
  }
}

// Main CLI entry point
const cli = new EVOCli();
const args = process.argv.slice(2);
const command = args[0];

(async () => {
  try {
    switch (command) {
      case 'login':
        await cli.login(args[1], args[2]);
        break;
      case 'scan':
        await cli.scanAWS(args[1]);
        break;
      case 'refresh-views':
        await cli.refreshMaterializedViews();
        break;
      case 'costs':
        await cli.getCosts(args[1], args[2], args[3]);
        break;
      case 'export':
        await cli.exportData(args[1], (args[2] as 'json' | 'csv') || 'json');
        break;
      case 'health':
        await cli.getSystemHealth();
        break;
      case 'events':
        await cli.getEvents(args[1], parseInt(args[2]) || 10);
        break;
      case 'validate-license':
        await cli.validateLicense(args[1]);
        break;
      case 'help':
      default:
        cli.showHelp();
        break;
    }
  } catch (error) {
    console.error('❌ Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
})();
