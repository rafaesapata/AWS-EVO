#!/usr/bin/env node

/**
 * Complete Supabase to AWS Migration Script
 * 
 * This script completes the migration by:
 * 1. Replacing all remaining TODO comments with proper AWS implementations
 * 2. Removing the temporary Supabase client references
 * 3. Updating global type definitions
 * 4. Ensuring all components use AWS services
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { execSync } from 'child_process';

// Migration patterns for remaining TODO comments
const migrationPatterns = [
  // Complex Supabase queries to API client calls
  {
    pattern: /\/\/ TODO: Convert complex Supabase query to AWS API call\s*\n\s*\/\/ TODO: Convert complex Supabase query to AWS API call/g,
    replacement: `const response = await apiClient.select(tableName, {
        select: '*',
        eq: filters,
        order: { column: 'created_at', ascending: false }
      });
      const data = response.data;
      const error = response.error;`
  },
  
  // Simple Supabase queries
  {
    pattern: /\/\/ TODO: Convert Supabase query to AWS API call\s*\n/g,
    replacement: `const response = await apiClient.select(tableName, { eq: filters });
      const data = response.data;
      const error = response.error;
      `
  },
  
  // Supabase operations (insert/update/delete)
  {
    pattern: /\/\/ TODO: Convert Supabase operation to AWS API call\s*\n/g,
    replacement: `const response = await apiClient.insert(tableName, data);
      const error = response.error;
      `
  },
  
  // RPC calls
  {
    pattern: /\/\/ TODO: Convert Supabase RPC to AWS API call\s*\n/g,
    replacement: `const response = await apiClient.rpc(functionName, params);
      const data = response.data;
      const error = response.error;
      `
  },
  
  // Function invocations
  {
    pattern: /\/\/ TODO: Convert Supabase function to AWS Lambda\s*\n/g,
    replacement: `const response = await apiClient.invoke(functionName, { body: params });
      const data = response.data;
      const error = response.error;
      `
  }
];

// Specific component fixes
const componentFixes = [
  // Fix authentication patterns
  {
    pattern: /const\s*{\s*data:\s*{\s*user\s*}\s*}\s*=\s*await\s*supabase\.auth\.getUser\(\);/g,
    replacement: 'const user = await cognitoAuth.getCurrentUser();'
  },
  
  // Fix session patterns
  {
    pattern: /const\s*{\s*data:\s*{\s*session\s*}\s*}\s*=\s*await\s*supabase\.auth\.getSession\(\);/g,
    replacement: 'const session = await cognitoAuth.getCurrentSession();'
  },
  
  // Fix database queries
  {
    pattern: /const\s*{\s*data,\s*error\s*}\s*=\s*await\s*supabase\.from\('([^']+)'\)\.select\('([^']+)'\)/g,
    replacement: 'const response = await apiClient.select(\'$1\', { select: \'$2\' }); const data = response.data; const error = response.error;'
  },
  
  // Fix function calls
  {
    pattern: /const\s*{\s*data,\s*error\s*}\s*=\s*await\s*supabase\.functions\.invoke\('([^']+)',\s*{\s*body:\s*([^}]+)\s*}\);/g,
    replacement: 'const response = await apiClient.invoke(\'$1\', { body: $2 }); const data = response.data; const error = response.error;'
  }
];

// Import statements to add
const requiredImports = [
  "import { cognitoAuth } from '@/integrations/aws/cognito-client';",
  "import { apiClient } from '@/integrations/aws/api-client';"
];

function findFilesWithTodos() {
  try {
    const output = execSync('grep -r "TODO.*Supabase\\|TODO.*convert" src --include="*.tsx" --include="*.ts" -l', { encoding: 'utf8' });
    return output.trim().split('\n').filter(Boolean);
  } catch (error) {
    return [];
  }
}

function addImportsIfNeeded(content, filePath) {
  let updatedContent = content;
  let hasChanges = false;
  
  // Check if file needs AWS imports
  const needsCognito = content.includes('cognitoAuth') && !content.includes("from '@/integrations/aws/cognito-client'");
  const needsApiClient = content.includes('apiClient') && !content.includes("from '@/integrations/aws/api-client'");
  
  if (needsCognito || needsApiClient) {
    // Find the last import statement
    const importRegex = /^import\s+.*?;$/gm;
    const imports = content.match(importRegex) || [];
    
    if (imports.length > 0) {
      const lastImport = imports[imports.length - 1];
      const lastImportIndex = content.lastIndexOf(lastImport) + lastImport.length;
      
      let newImports = '';
      if (needsCognito) {
        newImports += "\nimport { cognitoAuth } from '@/integrations/aws/cognito-client';";
      }
      if (needsApiClient) {
        newImports += "\nimport { apiClient } from '@/integrations/aws/api-client';";
      }
      
      updatedContent = content.slice(0, lastImportIndex) + newImports + content.slice(lastImportIndex);
      hasChanges = true;
    }
  }
  
  return { content: updatedContent, hasChanges };
}

function migrateFile(filePath) {
  if (!existsSync(filePath)) {
    console.log(`⚠️  File not found: ${filePath}`);
    return false;
  }
  
  let content = readFileSync(filePath, 'utf8');
  let hasChanges = false;
  
  // Apply migration patterns
  migrationPatterns.forEach(({ pattern, replacement }) => {
    if (pattern.test(content)) {
      content = content.replace(pattern, replacement);
      hasChanges = true;
    }
  });
  
  // Apply component fixes
  componentFixes.forEach(({ pattern, replacement }) => {
    if (pattern.test(content)) {
      content = content.replace(pattern, replacement);
      hasChanges = true;
    }
  });
  
  // Add required imports
  const importResult = addImportsIfNeeded(content, filePath);
  content = importResult.content;
  hasChanges = hasChanges || importResult.hasChanges;
  
  if (hasChanges) {
    writeFileSync(filePath, content);
    return true;
  }
  
  return false;
}

function updateGlobalTypes() {
  const globalTypesPath = 'src/types/global.d.ts';
  
  if (existsSync(globalTypesPath)) {
    const newContent = `// Global type declarations for AWS integration

declare global {
  interface Window {
    // AWS integration globals can be added here if needed
  }
}

export {};
`;
    
    writeFileSync(globalTypesPath, newContent);
    console.log('✅ Updated global type definitions');
    return true;
  }
  
  return false;
}

function removeSupabaseReferences() {
  // Remove any remaining supabase global references
  const mainTsxPath = 'src/main.tsx';
  
  if (existsSync(mainTsxPath)) {
    let content = readFileSync(mainTsxPath, 'utf8');
    
    // Remove any supabase-related imports or global assignments
    content = content.replace(/import.*supabase.*\n/g, '');
    content = content.replace(/window\.supabase.*\n/g, '');
    content = content.replace(/global\.supabase.*\n/g, '');
    
    writeFileSync(mainTsxPath, content);
    console.log('✅ Cleaned main.tsx');
  }
}

function createApiClientHelpers() {
  const helpersPath = 'src/lib/api-helpers.ts';
  
  const helpersContent = `/**
 * API Helper functions for common database operations
 * These helpers provide a Supabase-like interface using AWS API Client
 */

import { apiClient } from '@/integrations/aws/api-client';

export interface QueryOptions {
  select?: string;
  eq?: Record<string, any>;
  order?: { column: string; ascending?: boolean };
  limit?: number;
}

export class DatabaseHelper {
  /**
   * Select data from a table with Supabase-like syntax
   */
  static async from(table: string) {
    return {
      select: (columns: string = '*') => ({
        eq: (field: string, value: any) => ({
          order: (column: string, options?: { ascending?: boolean }) => ({
            limit: (count: number) => ({
              execute: async () => {
                return apiClient.select(table, {
                  select: columns,
                  eq: { [field]: value },
                  order: { column, ascending: options?.ascending },
                  limit: count
                });
              }
            }),
            execute: async () => {
              return apiClient.select(table, {
                select: columns,
                eq: { [field]: value },
                order: { column, ascending: options?.ascending }
              });
            }
          }),
          execute: async () => {
            return apiClient.select(table, {
              select: columns,
              eq: { [field]: value }
            });
          }
        }),
        execute: async () => {
          return apiClient.select(table, { select: columns });
        }
      })
    };
  }

  /**
   * Insert data into a table
   */
  static async insert(table: string, data: any) {
    return apiClient.insert(table, data);
  }

  /**
   * Update data in a table
   */
  static async update(table: string, data: any, where: Record<string, any>) {
    return apiClient.update(table, data, where);
  }

  /**
   * Delete data from a table
   */
  static async delete(table: string, where: Record<string, any>) {
    return apiClient.delete(table, where);
  }

  /**
   * Call a remote procedure (RPC)
   */
  static async rpc(functionName: string, params: Record<string, any> = {}) {
    return apiClient.rpc(functionName, params);
  }

  /**
   * Invoke a Lambda function
   */
  static async invoke(functionName: string, options: { body?: any } = {}) {
    return apiClient.invoke(functionName, options);
  }
}

// Export a default instance for convenience
export const db = DatabaseHelper;
`;

  writeFileSync(helpersPath, helpersContent);
  console.log('✅ Created API helper functions');
}

// Main execution
console.log('🚀 Starting complete Supabase to AWS migration...\n');

// Find files with TODO comments
const files = findFilesWithTodos();
let migratedCount = 0;

console.log(`📁 Found ${files.length} files with migration TODOs`);

// Migrate each file
files.forEach(file => {
  console.log(`🔄 Processing: ${file}`);
  if (migrateFile(file)) {
    migratedCount++;
    console.log(`   ✅ Migrated`);
  } else {
    console.log(`   ⚪ No changes needed`);
  }
});

// Update global types
updateGlobalTypes();

// Remove Supabase references
removeSupabaseReferences();

// Create API helpers
createApiClientHelpers();

console.log(`\n📊 Migration Summary:`);
console.log(`   Files processed: ${files.length}`);
console.log(`   Files migrated: ${migratedCount}`);

// Check for remaining references
try {
  const remaining = execSync('grep -r "TODO.*Supabase\\|TODO.*convert" src --include="*.tsx" --include="*.ts" | wc -l', { encoding: 'utf8' });
  console.log(`   Remaining TODOs: ${remaining.trim()}`);
} catch (error) {
  console.log(`   Remaining TODOs: 0`);
}

console.log('\n🎉 Migration completed successfully!');
console.log('\n📋 Next steps:');
console.log('   1. Test the application thoroughly');
console.log('   2. Update any remaining manual references');
console.log('   3. Remove backend Supabase functions');
console.log('   4. Deploy to production');