#!/usr/bin/env node

/**
 * Script para migrar referências do Supabase para AWS
 * Automatiza as substituições mais comuns
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Padrões de substituição
const replacements = [
  // Auth patterns
  {
    pattern: /const\s*{\s*data:\s*{\s*user\s*}\s*}\s*=\s*await\s+supabase\.auth\.getUser\(\);/g,
    replacement: 'const user = await cognitoAuth.getCurrentUser();'
  },
  {
    pattern: /const\s*{\s*data:\s*{\s*session\s*}\s*}\s*=\s*await\s+supabase\.auth\.getSession\(\);/g,
    replacement: 'const session = await cognitoAuth.getCurrentSession();'
  },
  {
    pattern: /const\s*{\s*error\s*}\s*=\s*await\s+supabase\.auth\.signOut\(\);/g,
    replacement: 'await cognitoAuth.signOut();'
  },
  
  // Database query patterns
  {
    pattern: /supabase\.from\('([^']+)'\)\.select\('([^']+)'\)\.eq\('([^']+)',\s*([^)]+)\)\.maybeSingle\(\)/g,
    replacement: 'apiClient.get(\'/$1\', { $3: $4 })'
  },
  {
    pattern: /supabase\.from\('([^']+)'\)\.select\('([^']+)'\)\.eq\('([^']+)',\s*([^)]+)\)/g,
    replacement: 'apiClient.get(\'/$1\', { $3: $4 })'
  },
  {
    pattern: /supabase\.from\('([^']+)'\)\.select\('([^']+)'\)/g,
    replacement: 'apiClient.get(\'/$1\')'
  },
  {
    pattern: /supabase\.from\('([^']+)'\)\.insert\(([^)]+)\)/g,
    replacement: 'apiClient.post(\'/$1\', $2)'
  },
  {
    pattern: /supabase\.from\('([^']+)'\)\.update\(([^)]+)\)\.eq\('([^']+)',\s*([^)]+)\)/g,
    replacement: 'apiClient.put(\'/$1/$4\', $2)'
  },
  {
    pattern: /supabase\.from\('([^']+)'\)\.delete\(\)\.eq\('([^']+)',\s*([^)]+)\)/g,
    replacement: 'apiClient.delete(\'/$1/$3\')'
  },
  
  // Functions patterns
  {
    pattern: /supabase\.functions\.invoke\('([^']+)',\s*{\s*body:\s*([^}]+)\s*}\)/g,
    replacement: 'apiClient.lambda(\'$1\', $2)'
  },
  {
    pattern: /supabase\.functions\.invoke\('([^']+)'\)/g,
    replacement: 'apiClient.lambda(\'$1\')'
  },
  
  // RPC patterns
  {
    pattern: /supabase\.rpc\('([^']+)',\s*([^)]+)\)/g,
    replacement: 'apiClient.post(\'/rpc/$1\', $2)'
  },
  {
    pattern: /supabase\.rpc\('([^']+)'\)/g,
    replacement: 'apiClient.post(\'/rpc/$1\')'
  }
];

// Função para processar um arquivo
function processFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;
    
    // Aplicar todas as substituições
    for (const { pattern, replacement } of replacements) {
      const newContent = content.replace(pattern, replacement);
      if (newContent !== content) {
        content = newContent;
        modified = true;
      }
    }
    
    // Adicionar imports necessários se o arquivo foi modificado
    if (modified) {
      // Verificar se já tem os imports
      const hasCognitoImport = content.includes('cognitoAuth');
      const hasApiClientImport = content.includes('apiClient');
      
      let importsToAdd = [];
      
      if (content.includes('cognitoAuth') && !hasCognitoImport) {
        importsToAdd.push('import { cognitoAuth } from "@/integrations/aws/cognito-client";');
      }
      
      if (content.includes('apiClient') && !hasApiClientImport) {
        importsToAdd.push('import { apiClient } from "@/integrations/aws/api-client";');
      }
      
      if (importsToAdd.length > 0) {
        // Encontrar onde inserir os imports
        const importRegex = /^import\s+.*from\s+['"][^'"]+['"];?\s*$/gm;
        const imports = content.match(importRegex) || [];
        
        if (imports.length > 0) {
          // Inserir após o último import existente
          const lastImport = imports[imports.length - 1];
          const lastImportIndex = content.lastIndexOf(lastImport);
          const insertIndex = lastImportIndex + lastImport.length;
          
          content = content.slice(0, insertIndex) + '\n' + importsToAdd.join('\n') + content.slice(insertIndex);
        } else {
          // Inserir no início do arquivo
          content = importsToAdd.join('\n') + '\n' + content;
        }
      }
      
      // Salvar o arquivo modificado
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`✅ Migrated: ${filePath}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`❌ Error processing ${filePath}:`, error.message);
    return false;
  }
}

// Função para encontrar arquivos TypeScript/TSX
function findTsFiles(dir) {
  const files = [];
  
  function traverse(currentDir) {
    const items = fs.readdirSync(currentDir);
    
    for (const item of items) {
      const fullPath = path.join(currentDir, item);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        // Pular node_modules e outras pastas desnecessárias
        if (!['node_modules', '.git', 'dist', 'build'].includes(item)) {
          traverse(fullPath);
        }
      } else if (stat.isFile() && (item.endsWith('.ts') || item.endsWith('.tsx'))) {
        files.push(fullPath);
      }
    }
  }
  
  traverse(dir);
  return files;
}

// Executar migração
console.log('🔄 Starting Supabase to AWS migration...\n');

const srcDir = path.join(__dirname, 'src');
const files = findTsFiles(srcDir);

let processedCount = 0;
let modifiedCount = 0;

for (const file of files) {
  processedCount++;
  if (processFile(file)) {
    modifiedCount++;
  }
}

console.log(`\n📊 Migration Summary:`);
console.log(`   Files processed: ${processedCount}`);
console.log(`   Files modified: ${modifiedCount}`);
console.log(`   Files unchanged: ${processedCount - modifiedCount}`);

if (modifiedCount > 0) {
  console.log(`\n✅ Migration completed! ${modifiedCount} files were updated.`);
  console.log(`\n⚠️  Next steps:`);
  console.log(`   1. Review the changes`);
  console.log(`   2. Test the application`);
  console.log(`   3. Fix any remaining manual cases`);
  console.log(`   4. Remove the temporary Supabase client`);
} else {
  console.log(`\n✅ No files needed migration.`);
}