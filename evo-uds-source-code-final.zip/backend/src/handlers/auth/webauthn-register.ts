import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { PrismaClient } from '@prisma/client';
import * as crypto from 'crypto';

const prisma = new PrismaClient();

interface RegistrationRequest {
  action: 'start' | 'finish';
  userId?: string;
  deviceName?: string;
  attestation?: {
    id: string;
    rawId: string;
    type: string;
    response: {
      clientDataJSON: string;
      attestationObject: string;
    };
  };
  challenge?: string;
}

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    const authUserId = event.requestContext.authorizer?.claims?.sub;
    if (!authUserId) {
      return { statusCode: 401, body: JSON.stringify({ error: 'Unauthorized' }) };
    }

    const body: RegistrationRequest = JSON.parse(event.body || '{}');
    const { action } = body;

    if (action === 'start') {
      return await startRegistration(authUserId, body.deviceName);
    } else if (action === 'finish') {
      return await finishRegistration(authUserId, body);
    }

    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid action' }) };
  } catch (error) {
    console.error('WebAuthn registration error:', error);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal server error' }) };
  }
};

async function startRegistration(userId: string, deviceName?: string): Promise<APIGatewayProxyResult> {
  // Buscar usuário
  const user = await prisma.user.findUnique({
    where: { cognitoId: userId },
    include: { webauthnCredentials: true }
  });

  if (!user) {
    return { statusCode: 404, body: JSON.stringify({ error: 'User not found' }) };
  }

  // Gerar challenge
  const challenge = crypto.randomBytes(32).toString('base64url');
  const challengeExpiry = new Date(Date.now() + 300000); // 5 minutos

  // Salvar challenge
  await prisma.webauthnChallenge.create({
    data: {
      challenge,
      userId: user.id,
      type: 'REGISTRATION',
      deviceName: deviceName || 'Unknown Device',
      expiresAt: challengeExpiry
    }
  });

  // Gerar opções de registro
  const rpId = process.env.WEBAUTHN_RP_ID || 'evouds.com';
  const rpName = process.env.WEBAUTHN_RP_NAME || 'EVO UDS';

  const publicKeyCredentialCreationOptions = {
    challenge,
    rp: {
      id: rpId,
      name: rpName
    },
    user: {
      id: Buffer.from(user.id).toString('base64url'),
      name: user.email,
      displayName: user.name
    },
    pubKeyCredParams: [
      { type: 'public-key', alg: -7 },   // ES256
      { type: 'public-key', alg: -257 }  // RS256
    ],
    authenticatorSelection: {
      authenticatorAttachment: 'platform',
      userVerification: 'preferred',
      residentKey: 'preferred'
    },
    timeout: 300000,
    attestation: 'direct',
    excludeCredentials: user.webauthnCredentials.map(cred => ({
      type: 'public-key',
      id: cred.credentialId
    }))
  };

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      success: true,
      options: publicKeyCredentialCreationOptions
    })
  };
}

async function finishRegistration(
  userId: string,
  body: RegistrationRequest
): Promise<APIGatewayProxyResult> {
  const { attestation, challenge, deviceName } = body;

  if (!attestation || !challenge) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing attestation or challenge' }) };
  }

  // Buscar usuário
  const user = await prisma.user.findUnique({
    where: { cognitoId: userId }
  });

  if (!user) {
    return { statusCode: 404, body: JSON.stringify({ error: 'User not found' }) };
  }

  // Verificar challenge
  const storedChallenge = await prisma.webauthnChallenge.findFirst({
    where: {
      challenge,
      userId: user.id,
      type: 'REGISTRATION',
      expiresAt: { gt: new Date() }
    }
  });

  if (!storedChallenge) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid or expired challenge' }) };
  }

  // Deletar challenge usado
  await prisma.webauthnChallenge.delete({ where: { id: storedChallenge.id } });

  try {
    // Decodificar e verificar attestation
    const clientDataJSON = Buffer.from(attestation.response.clientDataJSON, 'base64');
    const clientData = JSON.parse(clientDataJSON.toString());

    // Verificar challenge no clientData
    if (clientData.challenge !== challenge) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Challenge mismatch' }) };
    }

    // Verificar origin
    const expectedOrigin = process.env.WEBAUTHN_ORIGIN || 'https://evouds.com';
    if (clientData.origin !== expectedOrigin) {
      console.warn(`Origin mismatch: expected ${expectedOrigin}, got ${clientData.origin}`);
    }

    // Decodificar attestationObject (simplificado - em produção usar biblioteca CBOR)
    const attestationObject = Buffer.from(attestation.response.attestationObject, 'base64');
    
    // Extrair public key (simplificado)
    const publicKey = attestationObject.toString('base64');

    // Salvar credencial
    const credential = await prisma.webauthnCredential.create({
      data: {
        userId: user.id,
        credentialId: attestation.id,
        publicKey,
        counter: 0,
        deviceName: deviceName || storedChallenge.deviceName,
        transports: ['internal'],
        createdAt: new Date()
      }
    });

    // Registrar evento de segurança
    await prisma.securityEvent.create({
      data: {
        userId: user.id,
        eventType: 'WEBAUTHN_REGISTERED',
        severity: 'INFO',
        details: {
          credentialId: credential.id,
          deviceName: credential.deviceName
        },
        createdAt: new Date()
      }
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        success: true,
        credential: {
          id: credential.id,
          deviceName: credential.deviceName,
          createdAt: credential.createdAt
        }
      })
    };
  } catch (error) {
    console.error('Attestation verification error:', error);
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid attestation' }) };
  }
}
