/**
 * Lambda handler for Endpoint Monitor Check
 * Migrado de: supabase/functions/endpoint-monitor-check/index.ts
 * 
 * Monitora disponibilidade e performance de endpoints
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getUserFromEvent, getOrganizationId } from '../../lib/auth.js';
import { getPrismaClient } from '../../lib/database.js';

interface EndpointMonitorCheckRequest {
  endpointId?: string;
}

interface EndpointCheckResult {
  endpointId: string;
  url: string;
  status: 'up' | 'down' | 'degraded';
  statusCode?: number;
  responseTime: number;
  error?: string;
  checkedAt: Date;
}

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🚀 Endpoint Monitor Check started');
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const user = getUserFromEvent(event);
    const organizationId = getOrganizationId(user);
    
    const body: EndpointMonitorCheckRequest = event.body ? JSON.parse(event.body) : {};
    const { endpointId } = body;
    
    const prisma = getPrismaClient();
    
    // Buscar endpoints para monitorar
    const endpoints = await prisma.monitoredEndpoint.findMany({
      where: {
        organizationId,
        isActive: true,
        ...(endpointId && { id: endpointId }),
      },
    });
    
    if (endpoints.length === 0) {
      return success({
        success: true,
        message: 'No active endpoints to monitor',
        results: [],
      });
    }
    
    const results: EndpointCheckResult[] = [];
    
    // Verificar cada endpoint
    for (const endpoint of endpoints) {
      const result = await checkEndpoint(endpoint.url, endpoint.timeout || 5000);
      
      results.push({
        endpointId: endpoint.id,
        url: endpoint.url,
        status: result.status,
        statusCode: result.statusCode,
        responseTime: result.responseTime,
        error: result.error,
        checkedAt: new Date(),
      });
      
      // Salvar resultado no banco
      await prisma.endpointCheckHistory.create({
        data: {
          endpointId: endpoint.id,
          status: result.status,
          statusCode: result.statusCode,
          responseTime: result.responseTime,
          error: result.error,
          checkedAt: new Date(),
        },
      });
      
      // Atualizar status do endpoint
      await prisma.monitoredEndpoint.update({
        where: { id: endpoint.id },
        data: {
          lastStatus: result.status,
          lastCheckedAt: new Date(),
          lastResponseTime: result.responseTime,
        },
      });
      
      // Criar alerta se endpoint estiver down
      if (result.status === 'down' && endpoint.alertOnFailure) {
        await prisma.alert.create({
          data: {
            organizationId,
            severity: 'HIGH',
            title: `Endpoint Down: ${endpoint.name}`,
            message: `Endpoint ${endpoint.url} is not responding. Error: ${result.error}`,
            metadata: {
              endpointId: endpoint.id,
              url: endpoint.url,
              statusCode: result.statusCode,
              responseTime: result.responseTime,
            },
            triggeredAt: new Date(),
          },
        });
      }
    }
    
    const upCount = results.filter(r => r.status === 'up').length;
    const downCount = results.filter(r => r.status === 'down').length;
    const degradedCount = results.filter(r => r.status === 'degraded').length;
    
    console.log(`✅ Checked ${results.length} endpoints: ${upCount} up, ${downCount} down, ${degradedCount} degraded`);
    
    return success({
      success: true,
      results,
      summary: {
        total: results.length,
        up: upCount,
        down: downCount,
        degraded: degradedCount,
        avgResponseTime: results.reduce((sum, r) => sum + r.responseTime, 0) / results.length,
      },
    });
    
  } catch (err) {
    console.error('❌ Endpoint Monitor Check error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}

async function checkEndpoint(
  url: string,
  timeout: number
): Promise<{
  status: 'up' | 'down' | 'degraded';
  statusCode?: number;
  responseTime: number;
  error?: string;
}> {
  const startTime = Date.now();
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    
    const response = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'EVO-UDS-Monitor/1.0',
      },
    });
    
    clearTimeout(timeoutId);
    
    const responseTime = Date.now() - startTime;
    const statusCode = response.status;
    
    // Determinar status
    let status: 'up' | 'down' | 'degraded';
    if (statusCode >= 200 && statusCode < 300) {
      status = responseTime > 2000 ? 'degraded' : 'up';
    } else if (statusCode >= 500) {
      status = 'down';
    } else {
      status = 'degraded';
    }
    
    return {
      status,
      statusCode,
      responseTime,
    };
    
  } catch (err) {
    const responseTime = Date.now() - startTime;
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    
    return {
      status: 'down',
      responseTime,
      error: errorMessage,
    };
  }
}
