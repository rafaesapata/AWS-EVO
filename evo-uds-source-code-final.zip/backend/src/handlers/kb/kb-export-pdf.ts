/**
 * Lambda handler for KB Export PDF
 * Migrado de: supabase/functions/kb-export-pdf/index.ts
 * 
 * Exporta artigo da KB para PDF
 */

import type { AuthorizedEvent, LambdaContext, APIGatewayProxyResultV2 } from '../../types/lambda.js';
import { success, error, corsOptions } from '../../lib/response.js';
import { getUserFromEvent, getOrganizationId } from '../../lib/auth.js';
import { getPrismaClient } from '../../lib/database.js';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

interface KBExportPDFRequest {
  articleId: string;
}

export async function handler(
  event: AuthorizedEvent,
  context: LambdaContext
): Promise<APIGatewayProxyResultV2> {
  console.log('🚀 KB Export PDF started');
  
  if (event.requestContext.http.method === 'OPTIONS') {
    return corsOptions();
  }
  
  try {
    const user = getUserFromEvent(event);
    const organizationId = getOrganizationId(user);
    
    const body: KBExportPDFRequest = event.body ? JSON.parse(event.body) : {};
    const { articleId } = body;
    
    if (!articleId) {
      return error('Missing required parameter: articleId');
    }
    
    const prisma = getPrismaClient();
    
    const article = await prisma.knowledgeBaseArticle.findFirst({
      where: {
        id: articleId,
        organizationId,
      },
    });
    
    if (!article) {
      return error('Article not found');
    }
    
    // Gerar HTML
    const html = generateArticleHTML(article);
    
    // Upload para S3
    const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });
    const bucketName = process.env.REPORTS_BUCKET_NAME || 'evo-uds-reports';
    const filename = `kb-article-${articleId}-${Date.now()}.html`;
    const key = `${organizationId}/kb/${filename}`;
    
    await s3Client.send(new PutObjectCommand({
      Bucket: bucketName,
      Key: key,
      Body: html,
      ContentType: 'text/html',
    }));
    
    const downloadUrl = await getSignedUrl(
      s3Client,
      new PutObjectCommand({ Bucket: bucketName, Key: key }),
      { expiresIn: 3600 }
    );
    
    console.log(`✅ Exported KB article: ${article.title}`);
    
    return success({
      success: true,
      filename,
      downloadUrl,
    });
    
  } catch (err) {
    console.error('❌ KB Export PDF error:', err);
    return error(err instanceof Error ? err.message : 'Internal server error');
  }
}

function generateArticleHTML(article: any): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <title>${article.title}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
    h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
    .meta { color: #666; font-size: 14px; margin: 20px 0; }
    .content { margin-top: 30px; }
    .tags { margin-top: 30px; }
    .tag { display: inline-block; background: #e9ecef; padding: 5px 10px; margin: 5px; border-radius: 3px; }
  </style>
</head>
<body>
  <h1>${article.title}</h1>
  
  <div class="meta">
    <p><strong>Category:</strong> ${article.category || 'Uncategorized'}</p>
    <p><strong>Created:</strong> ${new Date(article.createdAt).toLocaleDateString()}</p>
    <p><strong>Views:</strong> ${article.viewCount || 0}</p>
  </div>
  
  ${article.summary ? `<p><em>${article.summary}</em></p>` : ''}
  
  <div class="content">
    ${article.content}
  </div>
  
  ${article.tags && article.tags.length > 0 ? `
    <div class="tags">
      <strong>Tags:</strong>
      ${article.tags.map((tag: string) => `<span class="tag">${tag}</span>`).join('')}
    </div>
  ` : ''}
</body>
</html>
  `.trim();
}
