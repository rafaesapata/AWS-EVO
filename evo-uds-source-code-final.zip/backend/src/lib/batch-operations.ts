/**
 * Batch Operations System
 * Efficient batch processing for database operations and API calls
 */

import { logger } from './logging';
import { metricsCollector } from './metrics-collector';
import { cacheManager } from './redis-cache';

export interface BatchConfig {
  batchSize: number;
  maxConcurrency: number;
  retryAttempts: number;
  retryDelay: number;
  timeout: number;
  onProgress?: (processed: number, total: number) => void;
  onError?: (error: Error, item: any, index: number) => void;
  onSuccess?: (result: any, item: any, index: number) => void;
}

export interface BatchResult<T, R> {
  successful: Array<{ item: T; result: R; index: number }>;
  failed: Array<{ item: T; error: Error; index: number }>;
  totalProcessed: number;
  totalTime: number;
  successRate: number;
}

export interface BatchOperation<T, R> {
  items: T[];
  processor: (item: T, index: number) => Promise<R>;
  config: BatchConfig;
}

/**
 * Batch Processor
 */
export class BatchProcessor {
  private static readonly DEFAULT_CONFIG: BatchConfig = {
    batchSize: 10,
    maxConcurrency: 3,
    retryAttempts: 3,
    retryDelay: 1000,
    timeout: 30000,
  };

  /**
   * Process items in batches
   */
  static async process<T, R>(
    items: T[],
    processor: (item: T, index: number) => Promise<R>,
    config: Partial<BatchConfig> = {}
  ): Promise<BatchResult<T, R>> {
    const finalConfig = { ...this.DEFAULT_CONFIG, ...config };
    const startTime = Date.now();
    
    logger.info('Starting batch processing', {
      totalItems: items.length,
      batchSize: finalConfig.batchSize,
      maxConcurrency: finalConfig.maxConcurrency,
    });

    const successful: Array<{ item: T; result: R; index: number }> = [];
    const failed: Array<{ item: T; error: Error; index: number }> = [];

    // Split items into batches
    const batches = this.createBatches(items, finalConfig.batchSize);
    let processedCount = 0;

    // Process batches with concurrency control
    const semaphore = new Semaphore(finalConfig.maxConcurrency);

    await Promise.all(
      batches.map(async (batch, batchIndex) => {
        await semaphore.acquire();
        
        try {
          const batchResults = await this.processBatch(
            batch,
            processor,
            finalConfig,
            batchIndex * finalConfig.batchSize
          );

          successful.push(...batchResults.successful);
          failed.push(...batchResults.failed);
          
          processedCount += batch.length;
          finalConfig.onProgress?.(processedCount, items.length);

          metricsCollector.record('batch_processed', 1, {
            batchSize: batch.length.toString(),
            successCount: batchResults.successful.length.toString(),
            failureCount: batchResults.failed.length.toString(),
          });

        } catch (error) {
          logger.error('Batch processing failed', error as Error, {
            batchIndex,
            batchSize: batch.length,
          });

          // Mark all items in batch as failed
          batch.forEach((item, itemIndex) => {
            failed.push({
              item,
              error: error as Error,
              index: batchIndex * finalConfig.batchSize + itemIndex,
            });
          });
        } finally {
          semaphore.release();
        }
      })
    );

    const totalTime = Date.now() - startTime;
    const successRate = (successful.length / items.length) * 100;

    logger.info('Batch processing completed', {
      totalItems: items.length,
      successful: successful.length,
      failed: failed.length,
      successRate: `${successRate.toFixed(2)}%`,
      totalTime: `${totalTime}ms`,
    });

    metricsCollector.record('batch_operation_completed', 1, {
      totalItems: items.length.toString(),
      successRate: successRate.toString(),
      duration: totalTime.toString(),
    });

    return {
      successful,
      failed,
      totalProcessed: items.length,
      totalTime,
      successRate,
    };
  }

  /**
   * Process a single batch
   */
  private static async processBatch<T, R>(
    batch: T[],
    processor: (item: T, index: number) => Promise<R>,
    config: BatchConfig,
    baseIndex: number
  ): Promise<{
    successful: Array<{ item: T; result: R; index: number }>;
    failed: Array<{ item: T; error: Error; index: number }>;
  }> {
    const successful: Array<{ item: T; result: R; index: number }> = [];
    const failed: Array<{ item: T; error: Error; index: number }> = [];

    await Promise.all(
      batch.map(async (item, itemIndex) => {
        const globalIndex = baseIndex + itemIndex;
        
        try {
          const result = await this.processWithRetry(
            () => processor(item, globalIndex),
            config.retryAttempts,
            config.retryDelay,
            config.timeout
          );

          successful.push({ item, result, index: globalIndex });
          config.onSuccess?.(result, item, globalIndex);

        } catch (error) {
          failed.push({ item, error: error as Error, index: globalIndex });
          config.onError?.(error as Error, item, globalIndex);
        }
      })
    );

    return { successful, failed };
  }

  /**
   * Process with retry logic
   */
  private static async processWithRetry<R>(
    operation: () => Promise<R>,
    maxRetries: number,
    retryDelay: number,
    timeout: number
  ): Promise<R> {
    let lastError: Error;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await Promise.race([
          operation(),
          new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Operation timeout')), timeout)
          ),
        ]);
      } catch (error) {
        lastError = error as Error;
        
        if (attempt < maxRetries) {
          await new Promise(resolve => setTimeout(resolve, retryDelay * Math.pow(2, attempt)));
        }
      }
    }

    throw lastError!;
  }

  /**
   * Create batches from items
   */
  private static createBatches<T>(items: T[], batchSize: number): T[][] {
    const batches: T[][] = [];
    
    for (let i = 0; i < items.length; i += batchSize) {
      batches.push(items.slice(i, i + batchSize));
    }
    
    return batches;
  }
}

/**
 * Semaphore for concurrency control
 */
class Semaphore {
  private permits: number;
  private waitQueue: Array<() => void> = [];

  constructor(permits: number) {
    this.permits = permits;
  }

  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return;
    }

    return new Promise<void>(resolve => {
      this.waitQueue.push(resolve);
    });
  }

  release(): void {
    if (this.waitQueue.length > 0) {
      const resolve = this.waitQueue.shift()!;
      resolve();
    } else {
      this.permits++;
    }
  }
}

/**
 * Database Batch Operations
 */
export class DatabaseBatchOperations {
  /**
   * Batch insert with conflict resolution
   */
  static async batchInsert<T extends Record<string, any>>(
    tableName: string,
    records: T[],
    options: {
      batchSize?: number;
      onConflict?: 'ignore' | 'update' | 'error';
      conflictColumns?: string[];
      updateColumns?: string[];
    } = {}
  ): Promise<BatchResult<T, any>> {
    const { batchSize = 100, onConflict = 'error' } = options;

    return BatchProcessor.process(
      records,
      async (batch: T[]) => {
        // This would be implemented with your specific database client
        // Example with Prisma:
        /*
        if (onConflict === 'ignore') {
          return await prisma[tableName].createMany({
            data: batch,
            skipDuplicates: true,
          });
        } else if (onConflict === 'update') {
          return await Promise.all(
            batch.map(record =>
              prisma[tableName].upsert({
                where: { id: record.id },
                update: record,
                create: record,
              })
            )
          );
        } else {
          return await prisma[tableName].createMany({
            data: batch,
          });
        }
        */
        
        // Placeholder implementation
        return { count: batch.length };
      },
      { batchSize }
    );
  }

  /**
   * Batch update
   */
  static async batchUpdate<T extends Record<string, any>>(
    tableName: string,
    updates: Array<{ where: any; data: Partial<T> }>,
    options: { batchSize?: number } = {}
  ): Promise<BatchResult<any, any>> {
    const { batchSize = 50 } = options;

    return BatchProcessor.process(
      updates,
      async (update) => {
        // Implementation with your database client
        // return await prisma[tableName].update(update);
        return { updated: true };
      },
      { batchSize }
    );
  }

  /**
   * Batch delete
   */
  static async batchDelete(
    tableName: string,
    conditions: any[],
    options: { batchSize?: number } = {}
  ): Promise<BatchResult<any, any>> {
    const { batchSize = 100 } = options;

    return BatchProcessor.process(
      conditions,
      async (condition) => {
        // Implementation with your database client
        // return await prisma[tableName].deleteMany({ where: condition });
        return { deleted: true };
      },
      { batchSize }
    );
  }
}

/**
 * API Batch Operations
 */
export class APIBatchOperations {
  /**
   * Batch API calls with rate limiting
   */
  static async batchApiCalls<T, R>(
    items: T[],
    apiCall: (item: T) => Promise<R>,
    options: {
      batchSize?: number;
      maxConcurrency?: number;
      rateLimitDelay?: number;
    } = {}
  ): Promise<BatchResult<T, R>> {
    const { batchSize = 10, maxConcurrency = 3, rateLimitDelay = 100 } = options;

    return BatchProcessor.process(
      items,
      async (item, index) => {
        // Add delay for rate limiting
        if (rateLimitDelay > 0 && index > 0) {
          await new Promise(resolve => setTimeout(resolve, rateLimitDelay));
        }
        
        return await apiCall(item);
      },
      { batchSize, maxConcurrency }
    );
  }

  /**
   * Batch AWS API calls
   */
  static async batchAWSCalls<T, R>(
    items: T[],
    awsCall: (item: T) => Promise<R>,
    options: {
      batchSize?: number;
      maxConcurrency?: number;
      region?: string;
    } = {}
  ): Promise<BatchResult<T, R>> {
    const { batchSize = 5, maxConcurrency = 2 } = options;

    return BatchProcessor.process(
      items,
      async (item) => {
        try {
          return await awsCall(item);
        } catch (error: any) {
          // Handle AWS-specific errors
          if (error.name === 'ThrottlingException') {
            // Exponential backoff for throttling
            await new Promise(resolve => setTimeout(resolve, 2000));
            return await awsCall(item);
          }
          throw error;
        }
      },
      { 
        batchSize, 
        maxConcurrency,
        retryAttempts: 3,
        retryDelay: 1000,
      }
    );
  }
}

/**
 * File Processing Batch Operations
 */
export class FileBatchOperations {
  /**
   * Batch file processing
   */
  static async batchProcessFiles(
    filePaths: string[],
    processor: (filePath: string) => Promise<any>,
    options: {
      batchSize?: number;
      maxConcurrency?: number;
    } = {}
  ): Promise<BatchResult<string, any>> {
    const { batchSize = 5, maxConcurrency = 2 } = options;

    return BatchProcessor.process(
      filePaths,
      processor,
      { batchSize, maxConcurrency }
    );
  }

  /**
   * Batch file uploads
   */
  static async batchUploadFiles(
    files: Array<{ path: string; destination: string }>,
    uploader: (file: { path: string; destination: string }) => Promise<any>,
    options: {
      batchSize?: number;
      maxConcurrency?: number;
    } = {}
  ): Promise<BatchResult<any, any>> {
    const { batchSize = 3, maxConcurrency = 2 } = options;

    return BatchProcessor.process(
      files,
      uploader,
      { batchSize, maxConcurrency }
    );
  }
}

/**
 * Cache Batch Operations
 */
export class CacheBatchOperations {
  /**
   * Batch cache operations
   */
  static async batchCacheSet(
    keyValuePairs: Array<[string, any]>,
    options: {
      batchSize?: number;
      ttl?: number;
    } = {}
  ): Promise<BatchResult<[string, any], boolean>> {
    const { batchSize = 100, ttl } = options;

    return BatchProcessor.process(
      keyValuePairs,
      async (pair) => {
        const [key, value] = pair;
        return await cacheManager.set(key, value, { ttl });
      },
      { batchSize }
    );
  }

  /**
   * Batch cache get
   */
  static async batchCacheGet(
    keys: string[],
    options: { batchSize?: number } = {}
  ): Promise<BatchResult<string, any>> {
    const { batchSize = 100 } = options;

    return BatchProcessor.process(
      keys,
      async (key) => {
        return await cacheManager.get(key);
      },
      { batchSize }
    );
  }

  /**
   * Batch cache invalidation
   */
  static async batchCacheInvalidate(
    patterns: string[],
    options: { batchSize?: number } = {}
  ): Promise<BatchResult<string, number>> {
    const { batchSize = 50 } = options;

    return BatchProcessor.process(
      patterns,
      async (pattern) => {
        return await cacheManager.deletePattern(pattern);
      },
      { batchSize }
    );
  }
}

/**
 * Specialized batch operations for EVO UDS
 */
export class EVOBatchOperations {
  /**
   * Batch security scan processing
   */
  static async batchSecurityScans(
    accounts: Array<{ id: string; credentials: any }>,
    scanType: string
  ): Promise<BatchResult<any, any>> {
    return BatchProcessor.process(
      accounts,
      async (account) => {
        // Implementation would call security scan Lambda
        // return await invokeLambda('security-scan', { accountId: account.id, scanType });
        return { scanId: `scan-${account.id}-${Date.now()}` };
      },
      {
        batchSize: 3,
        maxConcurrency: 2,
        timeout: 300000, // 5 minutes per scan
      }
    );
  }

  /**
   * Batch cost analysis
   */
  static async batchCostAnalysis(
    accounts: Array<{ id: string; region: string }>,
    period: { start: Date; end: Date }
  ): Promise<BatchResult<any, any>> {
    return BatchProcessor.process(
      accounts,
      async (account) => {
        // Implementation would call cost analysis Lambda
        // return await invokeLambda('cost-analysis', { accountId: account.id, period });
        return { analysisId: `cost-${account.id}-${Date.now()}` };
      },
      {
        batchSize: 5,
        maxConcurrency: 3,
        timeout: 120000, // 2 minutes per analysis
      }
    );
  }

  /**
   * Batch findings processing
   */
  static async batchProcessFindings(
    findings: any[],
    processor: (finding: any) => Promise<any>
  ): Promise<BatchResult<any, any>> {
    return BatchProcessor.process(
      findings,
      processor,
      {
        batchSize: 50,
        maxConcurrency: 5,
        onProgress: (processed, total) => {
          logger.info(`Processing findings: ${processed}/${total}`);
        },
      }
    );
  }
}

// Export utility functions
export const batchUtils = {
  /**
   * Chunk array into smaller arrays
   */
  chunk<T>(array: T[], size: number): T[][] {
    return BatchProcessor['createBatches'](array, size);
  },

  /**
   * Delay execution
   */
  delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  },

  /**
   * Create progress tracker
   */
  createProgressTracker(total: number) {
    let processed = 0;
    
    return {
      increment() {
        processed++;
        const percentage = Math.round((processed / total) * 100);
        logger.info(`Progress: ${processed}/${total} (${percentage}%)`);
      },
      
      getProgress() {
        return { processed, total, percentage: (processed / total) * 100 };
      }
    };
  },
};

export {
  BatchProcessor,
  DatabaseBatchOperations,
  APIBatchOperations,
  FileBatchOperations,
  CacheBatchOperations,
  EVOBatchOperations,
};