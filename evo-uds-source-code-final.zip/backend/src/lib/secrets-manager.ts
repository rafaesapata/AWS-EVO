/**
 * AWS Secrets Manager Integration
 * Secure secrets management and rotation
 */

import { SecretsManager } from '@aws-sdk/client-secrets-manager';
import { KMS } from '@aws-sdk/client-kms';
import { logger } from './logging';
import { metricsCollector } from './metrics-collector';
import { cacheManager } from './redis-cache';

export interface SecretConfig {
  secretName: string;
  region?: string;
  versionId?: string;
  versionStage?: string;
}

export interface EncryptionConfig {
  keyId: string;
  region?: string;
  encryptionContext?: Record<string, string>;
}

export interface SecretValue {
  value: string;
  version: string;
  createdDate: Date;
  lastAccessedDate?: Date;
}

export interface DatabaseCredentials {
  username: string;
  password: string;
  host: string;
  port: number;
  database: string;
}

export interface AWSCredentials {
  accessKeyId: string;
  secretAccessKey: string;
  sessionToken?: string;
  region: string;
}

export interface APIKeys {
  [serviceName: string]: {
    apiKey: string;
    apiSecret?: string;
    endpoint?: string;
  };
}

/**
 * Secrets Manager Client
 */
export class SecretsManagerClient {
  private secretsManager: SecretsManager;
  private kms: KMS;
  private region: string;
  private cachePrefix = 'secrets';
  private defaultCacheTTL = 300; // 5 minutes

  constructor(region: string = process.env.AWS_REGION || 'us-east-1') {
    this.region = region;
    
    this.secretsManager = new SecretsManager({
      region: this.region,
      maxAttempts: 3,
      retryMode: 'adaptive',
    });

    this.kms = new KMS({
      region: this.region,
      maxAttempts: 3,
      retryMode: 'adaptive',
    });
  }

  /**
   * Get secret value
   */
  async getSecret(config: SecretConfig): Promise<SecretValue> {
    const cacheKey = `${config.secretName}:${config.versionId || config.versionStage || 'AWSCURRENT'}`;
    
    try {
      // Try cache first
      const cached = await cacheManager.get<SecretValue>(cacheKey, {
        prefix: this.cachePrefix,
        ttl: this.defaultCacheTTL
      });

      if (cached) {
        metricsCollector.record('secrets_cache_hit', 1, {
          secretName: config.secretName
        });
        return cached;
      }

      // Fetch from AWS Secrets Manager
      const startTime = Date.now();
      
      const response = await this.secretsManager.getSecretValue({
        SecretId: config.secretName,
        VersionId: config.versionId,
        VersionStage: config.versionStage || 'AWSCURRENT',
      });

      const duration = Date.now() - startTime;
      metricsCollector.record('secrets_fetch_duration', duration);
      metricsCollector.record('secrets_fetch_success', 1, {
        secretName: config.secretName
      });

      if (!response.SecretString) {
        throw new Error('Secret value is empty');
      }

      const secretValue: SecretValue = {
        value: response.SecretString,
        version: response.VersionId || 'unknown',
        createdDate: response.CreatedDate || new Date(),
        lastAccessedDate: new Date(),
      };

      // Cache the result
      await cacheManager.set(cacheKey, secretValue, {
        prefix: this.cachePrefix,
        ttl: this.defaultCacheTTL
      });

      logger.info('Secret retrieved successfully', {
        secretName: config.secretName,
        version: secretValue.version,
        duration
      });

      return secretValue;

    } catch (error) {
      logger.error('Failed to get secret', error as Error, {
        secretName: config.secretName,
        region: this.region
      });

      metricsCollector.record('secrets_fetch_error', 1, {
        secretName: config.secretName,
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Create or update secret
   */
  async putSecret(
    secretName: string, 
    secretValue: string | object,
    description?: string,
    kmsKeyId?: string
  ): Promise<string> {
    try {
      const secretString = typeof secretValue === 'string' 
        ? secretValue 
        : JSON.stringify(secretValue);

      const startTime = Date.now();

      // Try to update existing secret first
      try {
        const response = await this.secretsManager.updateSecret({
          SecretId: secretName,
          SecretString: secretString,
          Description: description,
          KmsKeyId: kmsKeyId,
        });

        const duration = Date.now() - startTime;
        metricsCollector.record('secrets_update_duration', duration);
        metricsCollector.record('secrets_update_success', 1, {
          secretName
        });

        // Invalidate cache
        await this.invalidateSecretCache(secretName);

        logger.info('Secret updated successfully', {
          secretName,
          version: response.VersionId,
          duration
        });

        return response.VersionId || 'unknown';

      } catch (updateError: any) {
        if (updateError.name === 'ResourceNotFoundException') {
          // Secret doesn't exist, create it
          const response = await this.secretsManager.createSecret({
            Name: secretName,
            SecretString: secretString,
            Description: description,
            KmsKeyId: kmsKeyId,
          });

          const duration = Date.now() - startTime;
          metricsCollector.record('secrets_create_duration', duration);
          metricsCollector.record('secrets_create_success', 1, {
            secretName
          });

          logger.info('Secret created successfully', {
            secretName,
            version: response.VersionId,
            duration
          });

          return response.VersionId || 'unknown';
        }

        throw updateError;
      }

    } catch (error) {
      logger.error('Failed to put secret', error as Error, {
        secretName,
        region: this.region
      });

      metricsCollector.record('secrets_put_error', 1, {
        secretName,
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Delete secret
   */
  async deleteSecret(
    secretName: string, 
    forceDelete: boolean = false,
    recoveryWindowInDays?: number
  ): Promise<void> {
    try {
      const startTime = Date.now();

      await this.secretsManager.deleteSecret({
        SecretId: secretName,
        ForceDeleteWithoutRecovery: forceDelete,
        RecoveryWindowInDays: recoveryWindowInDays,
      });

      const duration = Date.now() - startTime;
      metricsCollector.record('secrets_delete_duration', duration);
      metricsCollector.record('secrets_delete_success', 1, {
        secretName
      });

      // Invalidate cache
      await this.invalidateSecretCache(secretName);

      logger.info('Secret deleted successfully', {
        secretName,
        forceDelete,
        duration
      });

    } catch (error) {
      logger.error('Failed to delete secret', error as Error, {
        secretName,
        region: this.region
      });

      metricsCollector.record('secrets_delete_error', 1, {
        secretName,
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Rotate secret
   */
  async rotateSecret(
    secretName: string,
    lambdaFunctionArn?: string,
    rotationRules?: {
      automaticallyAfterDays: number;
    }
  ): Promise<string> {
    try {
      const startTime = Date.now();

      const response = await this.secretsManager.rotateSecret({
        SecretId: secretName,
        RotationLambdaARN: lambdaFunctionArn,
        RotationRules: rotationRules,
      });

      const duration = Date.now() - startTime;
      metricsCollector.record('secrets_rotate_duration', duration);
      metricsCollector.record('secrets_rotate_success', 1, {
        secretName
      });

      // Invalidate cache
      await this.invalidateSecretCache(secretName);

      logger.info('Secret rotation initiated', {
        secretName,
        version: response.VersionId,
        duration
      });

      return response.VersionId || 'unknown';

    } catch (error) {
      logger.error('Failed to rotate secret', error as Error, {
        secretName,
        region: this.region
      });

      metricsCollector.record('secrets_rotate_error', 1, {
        secretName,
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Encrypt data using KMS
   */
  async encrypt(
    plaintext: string | Buffer,
    config: EncryptionConfig
  ): Promise<string> {
    try {
      const startTime = Date.now();

      const response = await this.kms.encrypt({
        KeyId: config.keyId,
        Plaintext: Buffer.from(plaintext),
        EncryptionContext: config.encryptionContext,
      });

      const duration = Date.now() - startTime;
      metricsCollector.record('kms_encrypt_duration', duration);
      metricsCollector.record('kms_encrypt_success', 1);

      if (!response.CiphertextBlob) {
        throw new Error('Encryption failed - no ciphertext returned');
      }

      const encryptedData = Buffer.from(response.CiphertextBlob).toString('base64');

      logger.debug('Data encrypted successfully', {
        keyId: config.keyId,
        plaintextLength: plaintext.length,
        ciphertextLength: encryptedData.length,
        duration
      });

      return encryptedData;

    } catch (error) {
      logger.error('Failed to encrypt data', error as Error, {
        keyId: config.keyId
      });

      metricsCollector.record('kms_encrypt_error', 1, {
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Decrypt data using KMS
   */
  async decrypt(
    ciphertext: string,
    encryptionContext?: Record<string, string>
  ): Promise<string> {
    try {
      const startTime = Date.now();

      const response = await this.kms.decrypt({
        CiphertextBlob: Buffer.from(ciphertext, 'base64'),
        EncryptionContext: encryptionContext,
      });

      const duration = Date.now() - startTime;
      metricsCollector.record('kms_decrypt_duration', duration);
      metricsCollector.record('kms_decrypt_success', 1);

      if (!response.Plaintext) {
        throw new Error('Decryption failed - no plaintext returned');
      }

      const decryptedData = Buffer.from(response.Plaintext).toString('utf-8');

      logger.debug('Data decrypted successfully', {
        ciphertextLength: ciphertext.length,
        plaintextLength: decryptedData.length,
        duration
      });

      return decryptedData;

    } catch (error) {
      logger.error('Failed to decrypt data', error as Error);

      metricsCollector.record('kms_decrypt_error', 1, {
        errorType: (error as Error).name
      });

      throw error;
    }
  }

  /**
   * Get database credentials
   */
  async getDatabaseCredentials(secretName: string): Promise<DatabaseCredentials> {
    const secret = await this.getSecret({ secretName });
    
    try {
      const credentials = JSON.parse(secret.value) as DatabaseCredentials;
      
      // Validate required fields
      if (!credentials.username || !credentials.password || !credentials.host) {
        throw new Error('Invalid database credentials format');
      }

      return credentials;
    } catch (error) {
      logger.error('Failed to parse database credentials', error as Error, {
        secretName
      });
      throw new Error('Invalid database credentials format');
    }
  }

  /**
   * Get AWS credentials
   */
  async getAWSCredentials(secretName: string): Promise<AWSCredentials> {
    const secret = await this.getSecret({ secretName });
    
    try {
      const credentials = JSON.parse(secret.value) as AWSCredentials;
      
      // Validate required fields
      if (!credentials.accessKeyId || !credentials.secretAccessKey) {
        throw new Error('Invalid AWS credentials format');
      }

      return credentials;
    } catch (error) {
      logger.error('Failed to parse AWS credentials', error as Error, {
        secretName
      });
      throw new Error('Invalid AWS credentials format');
    }
  }

  /**
   * Get API keys
   */
  async getAPIKeys(secretName: string): Promise<APIKeys> {
    const secret = await this.getSecret({ secretName });
    
    try {
      const apiKeys = JSON.parse(secret.value) as APIKeys;
      return apiKeys;
    } catch (error) {
      logger.error('Failed to parse API keys', error as Error, {
        secretName
      });
      throw new Error('Invalid API keys format');
    }
  }

  /**
   * Invalidate secret cache
   */
  private async invalidateSecretCache(secretName: string): Promise<void> {
    await cacheManager.deletePattern(`${secretName}:*`, {
      prefix: this.cachePrefix
    });
  }

  /**
   * List secrets
   */
  async listSecrets(filters?: {
    namePrefix?: string;
    tagFilters?: Array<{ key: string; values: string[] }>;
  }): Promise<Array<{
    name: string;
    description?: string;
    lastChangedDate?: Date;
    tags?: Record<string, string>;
  }>> {
    try {
      const response = await this.secretsManager.listSecrets({
        Filters: filters?.tagFilters?.map(filter => ({
          Key: 'tag-key',
          Values: [filter.key]
        })),
        MaxResults: 100,
      });

      const secrets = response.SecretList?.map(secret => ({
        name: secret.Name || '',
        description: secret.Description,
        lastChangedDate: secret.LastChangedDate,
        tags: secret.Tags?.reduce((acc, tag) => {
          if (tag.Key && tag.Value) {
            acc[tag.Key] = tag.Value;
          }
          return acc;
        }, {} as Record<string, string>),
      })) || [];

      // Filter by name prefix if provided
      if (filters?.namePrefix) {
        return secrets.filter(secret => 
          secret.name.startsWith(filters.namePrefix!)
        );
      }

      return secrets;

    } catch (error) {
      logger.error('Failed to list secrets', error as Error);
      throw error;
    }
  }

  /**
   * Health check
   */
  async healthCheck(): Promise<{
    status: 'healthy' | 'unhealthy';
    latency?: number;
    error?: string;
  }> {
    try {
      const startTime = Date.now();
      
      // Try to list secrets (minimal operation)
      await this.secretsManager.listSecrets({ MaxResults: 1 });
      
      const latency = Date.now() - startTime;
      
      return { status: 'healthy', latency };
    } catch (error) {
      return {
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }
}

/**
 * Secrets Manager for different environments
 */
export class EnvironmentSecretsManager {
  private client: SecretsManagerClient;
  private environment: string;

  constructor(environment: string = process.env.NODE_ENV || 'development') {
    this.environment = environment;
    this.client = new SecretsManagerClient();
  }

  private getSecretName(baseName: string): string {
    return `evo-uds/${this.environment}/${baseName}`;
  }

  async getDatabaseCredentials(): Promise<DatabaseCredentials> {
    return this.client.getDatabaseCredentials(
      this.getSecretName('database')
    );
  }

  async getAWSCredentials(accountName: string): Promise<AWSCredentials> {
    return this.client.getAWSCredentials(
      this.getSecretName(`aws/${accountName}`)
    );
  }

  async getAPIKeys(): Promise<APIKeys> {
    return this.client.getAPIKeys(
      this.getSecretName('api-keys')
    );
  }

  async getJWTSecret(): Promise<string> {
    const secret = await this.client.getSecret({
      secretName: this.getSecretName('jwt-secret')
    });
    return secret.value;
  }

  async getEncryptionKey(): Promise<string> {
    const secret = await this.client.getSecret({
      secretName: this.getSecretName('encryption-key')
    });
    return secret.value;
  }
}

// Global instances
export const secretsManager = new SecretsManagerClient();
export const envSecretsManager = new EnvironmentSecretsManager();

// Utility functions
export async function withSecrets<T>(
  secretNames: string[],
  callback: (secrets: Record<string, SecretValue>) => Promise<T>
): Promise<T> {
  const secrets: Record<string, SecretValue> = {};
  
  // Fetch all secrets in parallel
  await Promise.all(
    secretNames.map(async (name) => {
      secrets[name] = await secretsManager.getSecret({ secretName: name });
    })
  );

  return callback(secrets);
}

export function createSecretRotationLambda(
  secretName: string,
  rotationLogic: (currentSecret: string) => Promise<string>
) {
  return async (event: any) => {
    const { Step, SecretId, Token } = event;
    
    try {
      switch (Step) {
        case 'createSecret':
          // Generate new secret
          const currentSecret = await secretsManager.getSecret({ 
            secretName: SecretId,
            versionStage: 'AWSCURRENT'
          });
          
          const newSecret = await rotationLogic(currentSecret.value);
          
          await secretsManager.putSecret(SecretId, newSecret);
          break;

        case 'setSecret':
          // Set the secret in the service
          // Implementation depends on the service
          break;

        case 'testSecret':
          // Test the new secret
          // Implementation depends on the service
          break;

        case 'finishSecret':
          // Finalize the rotation
          // Implementation depends on the service
          break;
      }

      return { statusCode: 200, body: 'Success' };
    } catch (error) {
      logger.error('Secret rotation failed', error as Error, {
        secretId: SecretId,
        step: Step
      });
      
      return { statusCode: 500, body: 'Failed' };
    }
  };
}