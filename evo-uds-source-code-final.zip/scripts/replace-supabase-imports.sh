#!/bin/bash

# Script to replace Supabase imports with AWS equivalents

echo "🔄 Replacing Supabase imports with AWS equivalents..."

# Find all TypeScript/TSX files that import from supabase/client
files=$(find src -name "*.tsx" -o -name "*.ts" | grep -v test | xargs grep -l "@/integrations/supabase/client")

count=0
for file in $files; do
    echo "📝 Processing: $file"
    
    # Replace the import statement
    sed -i '' 's|import { supabase } from "@/integrations/supabase/client";|import { cognitoAuth } from "@/integrations/aws/cognito-client";\nimport { apiClient } from "@/integrations/aws/api-client";|g' "$file"
    
    # Also handle cases where there might be other imports on the same line
    sed -i '' 's|import.*supabase.*from "@/integrations/supabase/client";|import { cognitoAuth } from "@/integrations/aws/cognito-client";\nimport { apiClient } from "@/integrations/aws/api-client";|g' "$file"
    
    count=$((count + 1))
done

echo "✅ Processed $count files"
echo "⚠️  Note: You'll need to manually update the actual supabase usage in these files"
echo "   Common replacements needed:"
echo "   - supabase.auth.getUser() → cognitoAuth.getCurrentUser()"
echo "   - supabase.from('table') → apiClient.select('table')"
echo "   - supabase.functions.invoke() → apiClient.invoke()"
echo "   - supabase.rpc() → apiClient.rpc()"