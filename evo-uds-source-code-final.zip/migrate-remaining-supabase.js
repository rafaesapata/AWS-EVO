#!/usr/bin/env node

/**
 * Script para migrar as referências restantes do Supabase para AWS
 * Trata casos mais complexos que o script anterior não conseguiu
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Substituições mais específicas para casos complexos
const complexReplacements = [
  // Auth patterns mais específicos
  {
    pattern: /const\s*{\s*data:\s*userData\s*}\s*=\s*await\s+supabase\.auth\.getUser\(\);/g,
    replacement: 'const userData = await cognitoAuth.getCurrentUser();'
  },
  {
    pattern: /const\s*{\s*data:\s*{\s*session\s*},\s*error:\s*sessionError\s*}\s*=\s*await\s+supabase\.auth\.getSession\(\);/g,
    replacement: 'const session = await cognitoAuth.getCurrentSession(); const sessionError = null;'
  },
  
  // Query patterns mais complexos
  {
    pattern: /let\s+query\s*=\s*supabase\.from\('([^']+)'\)/g,
    replacement: 'let query = { from: \'$1\', filters: {}, select: \'*\' }; // TODO: Convert to apiClient'
  },
  
  // Functions com múltiplas linhas
  {
    pattern: /const\s*{\s*data,\s*error\s*}\s*=\s*await\s+supabase\.functions\.invoke\('([^']+)',\s*{\s*body:\s*([^}]+)\s*}\);/g,
    replacement: 'const data = await apiClient.lambda(\'$1\', $2); const error = null;'
  },
  {
    pattern: /const\s*{\s*data,\s*error\s*}\s*=\s*await\s+supabase\.functions\.invoke\('([^']+)'\);/g,
    replacement: 'const data = await apiClient.lambda(\'$1\'); const error = null;'
  }
];

// Função para processar um arquivo
function processFile(filePath) {
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    let modified = false;
    
    // Aplicar substituições complexas
    for (const { pattern, replacement } of complexReplacements) {
      const newContent = content.replace(pattern, replacement);
      if (newContent !== content) {
        content = newContent;
        modified = true;
      }
    }
    
    // Adicionar imports se necessário
    if (modified) {
      const needsCognito = content.includes('cognitoAuth') && !content.includes('import { cognitoAuth }');
      const needsApiClient = content.includes('apiClient') && !content.includes('import { apiClient }');
      
      if (needsCognito || needsApiClient) {
        let imports = [];
        if (needsCognito) imports.push('import { cognitoAuth } from "@/integrations/aws/cognito-client";');
        if (needsApiClient) imports.push('import { apiClient } from "@/integrations/aws/api-client";');
        
        // Inserir imports após os imports existentes
        const importRegex = /^import\s+.*from\s+['"][^'"]+['"];?\s*$/gm;
        const existingImports = content.match(importRegex) || [];
        
        if (existingImports.length > 0) {
          const lastImport = existingImports[existingImports.length - 1];
          const lastImportIndex = content.lastIndexOf(lastImport);
          const insertIndex = lastImportIndex + lastImport.length;
          content = content.slice(0, insertIndex) + '\n' + imports.join('\n') + content.slice(insertIndex);
        } else {
          content = imports.join('\n') + '\n' + content;
        }
      }
      
      fs.writeFileSync(filePath, content, 'utf8');
      console.log(`✅ Fixed: ${filePath}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error(`❌ Error processing ${filePath}:`, error.message);
    return false;
  }
}

import { execSync } from 'child_process';

// Encontrar arquivos que ainda têm referências ao supabase
function findFilesWithSupabase() {
  try {
    const output = execSync('grep -r "supabase\\." src --include="*.tsx" --include="*.ts" -l', { encoding: 'utf8' });
    return output.trim().split('\n').filter(Boolean);
  } catch (error) {
    return [];
  }
}

console.log('🔄 Fixing remaining Supabase references...\n');

const files = findFilesWithSupabase();
let modifiedCount = 0;

for (const file of files) {
  if (processFile(file)) {
    modifiedCount++;
  }
}

console.log(`\n📊 Summary:`);
console.log(`   Files with Supabase references: ${files.length}`);
console.log(`   Files fixed: ${modifiedCount}`);

// Verificar quantas referências ainda restam
try {
  const remaining = execSync('grep -r "supabase\\." src --include="*.tsx" --include="*.ts" | wc -l', { encoding: 'utf8' });
  console.log(`   Remaining references: ${remaining.trim()}`);
} catch (error) {
  console.log(`   Could not count remaining references`);
}

if (modifiedCount > 0) {
  console.log(`\n✅ Fixed ${modifiedCount} more files!`);
} else {
  console.log(`\n✅ No additional fixes were possible with automated patterns.`);
}

console.log(`\n⚠️  Manual review needed for remaining complex cases.`);